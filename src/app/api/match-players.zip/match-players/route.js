import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";


const VALID_ROLES = ["playing_11", "substitute", "captain", "vice_captain", "wicket_keeper"];

const toBoolean = (value) => {
    return value === true || value === 1 || value === "1";
};

const isPositiveInt = (value) => {
    return Number.isInteger(Number(value)) && Number(value) > 0;
};

const getPlayerReference = (body) => {
    const userId = body.user_id ? Number(body.user_id) : null;
    const outsidePlayerId = body.outside_player_id
        ? Number(body.outside_player_id)
        : null;
    const tournamentPlayerId = body.tournament_team_player_id
        ? Number(body.tournament_team_player_id)
        : null;

    const count = [userId, outsidePlayerId, tournamentPlayerId]
        .filter((value) => value !== null).length;

    if (count !== 1) {
        return {
            valid: false,
            message:
                "Provide exactly one of user_id, outside_player_id or tournament_team_player_id.",
        };
    }

    for (const value of [userId, outsidePlayerId, tournamentPlayerId]) {
        if (value !== null && !isPositiveInt(value)) {
            return {
                valid: false,
                message: "Player IDs must be positive integers.",
            };
        }
    }

    return {
        valid: true,
        user_id: userId,
        outside_player_id: outsidePlayerId,
        tournament_team_player_id: tournamentPlayerId,
    };
};

async function validatePlayer(connection, player, matchId, teamId) {
    if (player.user_id !== null) {
        const [users] = await connection.execute(
            `SELECT id
             FROM cst_users
             WHERE id = ?
             LIMIT 1`,
            [player.user_id]
        );

        if (!users.length) {
            return "Registered user not found.";
        }
    }

    if (player.outside_player_id !== null) {
        const [outsidePlayers] = await connection.execute(
            `SELECT id
             FROM cst_outside_players
             WHERE id = ?
             LIMIT 1`,
            [player.outside_player_id]
        );

        if (!outsidePlayers.length) {
            return "Outside player not found.";
        }
    }

    if (player.tournament_team_player_id !== null) {
        const [tournamentPlayers] = await connection.execute(
            `SELECT id, team_id
             FROM cst_tournament_team_players
             WHERE id = ?
             LIMIT 1`,
            [player.tournament_team_player_id]
        );

        if (!tournamentPlayers.length) {
            return "Tournament team player not found.";
        }

        if (Number(tournamentPlayers[0].team_id) !== Number(teamId)) {
            return "Tournament player does not belong to the selected team.";
        }

        const [matches] = await connection.execute(
            `SELECT tournament_id
             FROM cst_matches
             WHERE id = ?
             LIMIT 1`,
            [matchId]
        );

        if (!matches.length || !matches[0].tournament_id) {
            return "Tournament player can only be selected for a tournament match.";
        }

        const [tournamentTeams] = await connection.execute(
            `SELECT id
             FROM cst_tournament_teams
             WHERE tournament_id = ?
               AND team_id = ?
             LIMIT 1`,
            [matches[0].tournament_id, teamId]
        );

        if (!tournamentTeams.length) {
            return "Selected team is not registered in this tournament.";
        }
    }

    return null;
}

async function validateMatchTeam(connection, matchId, teamId) {
    const [matches] = await connection.execute(
        `SELECT id, team_a_id, team_b_id
         FROM cst_matches
         WHERE id = ?
         LIMIT 1`,
        [matchId]
    );

    if (!matches.length) {
        return {
            valid: false,
            message: "Match not found.",
        };
    }

    const match = matches[0];

    if (
        Number(match.team_a_id) !== Number(teamId) &&
        Number(match.team_b_id) !== Number(teamId)
    ) {
        return {
            valid: false,
            message: "Selected team does not belong to this match.",
        };
    }

    return { valid: true };
}

function validateSelection(body) {
    const selection = {
        playing_11: toBoolean(body.playing_11) ? 1 : 0,
        substitute: toBoolean(body.substitute) ? 1 : 0,
        captain: toBoolean(body.captain) ? 1 : 0,
        vice_captain: toBoolean(body.vice_captain) ? 1 : 0,
        wicket_keeper: toBoolean(body.wicket_keeper) ? 1 : 0,
        jersey_no: body.jersey_no ? String(body.jersey_no).trim() : null,
        status: body.status === undefined ? 1 : Number(body.status),
    };

    if (![0, 1].includes(selection.status)) {
        return {
            valid: false,
            message: "status must be 0 or 1.",
        };
    }

    if (
        selection.captain &&
        selection.vice_captain
    ) {
        return {
            valid: false,
            message: "A player cannot be both captain and vice-captain.",
        };
    }

    if (
        (selection.captain ||
            selection.vice_captain ||
            selection.wicket_keeper) &&
        !selection.playing_11
    ) {
        return {
            valid: false,
            message:
                "Captain, vice-captain and wicket-keeper must be in playing_11.",
        };
    }

    if (selection.playing_11 && selection.substitute) {
        return {
            valid: false,
            message:
                "A player cannot be in playing_11 and substitute at the same time.",
        };
    }

    return {
        valid: true,
        data: selection,
    };
}

// GET /api/match-players
// Example:
// /api/match-players?match_id=10
// /api/match-players?match_id=10&team_id=2
// /api/match-players?playing_11=1
// /api/match-players?user_id=25

export async function GET(request) {
    let connection;

    try {
        const { searchParams } = new URL(request.url);

        const filters = {
            id: searchParams.get("id"),
            match_id: searchParams.get("match_id"),
            team_id: searchParams.get("team_id"),
            user_id: searchParams.get("user_id"),
            outside_player_id: searchParams.get("outside_player_id"),
            tournament_team_player_id: searchParams.get(
                "tournament_team_player_id"
            ),
            playing_11: searchParams.get("playing_11"),
            substitute: searchParams.get("substitute"),
            captain: searchParams.get("captain"),
            vice_captain: searchParams.get("vice_captain"),
            wicket_keeper: searchParams.get("wicket_keeper"),
            status: searchParams.get("status"),
        };

        const conditions = [];
        const values = [];

        const numericFilters = [
            "id",
            "match_id",
            "team_id",
            "user_id",
            "outside_player_id",
            "tournament_team_player_id",
        ];

        for (const key of numericFilters) {
            if (filters[key] !== null && filters[key] !== "") {
                if (!isPositiveInt(filters[key])) {
                    return NextResponse.json(
                        {
                            success: false,
                            message: `${key} must be a positive integer.`,
                        },
                        { status: 400 }
                    );
                }

                conditions.push(`mp.${key} = ?`);
                values.push(Number(filters[key]));
            }
        }

        for (const key of [
            "playing_11",
            "substitute",
            "captain",
            "vice_captain",
            "wicket_keeper",
            "status",
        ]) {
            if (filters[key] !== null && filters[key] !== "") {
                if (!["0", "1"].includes(filters[key])) {
                    return NextResponse.json(
                        {
                            success: false,
                            message: `${key} must be 0 or 1.`,
                        },
                        { status: 400 }
                    );
                }

                conditions.push(`mp.${key} = ?`);
                values.push(Number(filters[key]));
            }
        }

        connection = await pool.getConnection();

        const whereClause = conditions.length
            ? `WHERE ${conditions.join(" AND ")}`
            : "";

        const [rows] = await connection.execute(
            `SELECT
                mp.*,
                m.match_no,
                m.match_type,
                m.match_date,
                m.status AS match_status,
                m.tournament_id,
                t.team_name,
                t.team_code,
                u.first_name,
                u.last_name,
                op.id AS outside_player_record_id,
                ttp.id AS tournament_player_record_id
             FROM cst_match_players mp
             INNER JOIN cst_matches m ON m.id = mp.match_id
             INNER JOIN cst_teams t ON t.id = mp.team_id
             LEFT JOIN cst_users u ON u.id = mp.user_id
             LEFT JOIN cst_outside_players op
                ON op.id = mp.outside_player_id
             LEFT JOIN cst_tournament_team_players ttp
                ON ttp.id = mp.tournament_team_player_id
             ${whereClause}
             ORDER BY mp.id DESC`,
            values
        );

        return NextResponse.json({
            success: true,
            count: rows.length,
            data: rows,
        });
    } catch (error) {
        console.error("GET match players error:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to fetch match players.",
            },
            { status: 500 }
        );
    } finally {
        if (connection) connection.release();
    }
}

// POST /api/match-players
export async function POST(request) {
    let connection;

    try {
        const body = await request.json();

        const matchId = Number(body.match_id);
        const teamId = Number(body.team_id);

        if (!isPositiveInt(matchId) || !isPositiveInt(teamId)) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Valid match_id and team_id are required.",
                },
                { status: 400 }
            );
        }

        const player = getPlayerReference(body);

        if (!player.valid) {
            return NextResponse.json(
                { success: false, message: player.message },
                { status: 400 }
            );
        }

        const selection = validateSelection(body);

        if (!selection.valid) {
            return NextResponse.json(
                { success: false, message: selection.message },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();
        await connection.beginTransaction();

        const matchTeam = await validateMatchTeam(
            connection,
            matchId,
            teamId
        );

        if (!matchTeam.valid) {
            await connection.rollback();

            return NextResponse.json(
                {
                    success: false,
                    message: matchTeam.message,
                },
                { status: 400 }
            );
        }

        const playerError = await validatePlayer(
            connection,
            player,
            matchId,
            teamId
        );

        if (playerError) {
            await connection.rollback();

            return NextResponse.json(
                {
                    success: false,
                    message: playerError,
                },
                { status: 400 }
            );
        }

        // Check whether this player has already been selected for this match.
        const identityColumn =
            player.user_id !== null
                ? "user_id"
                : player.outside_player_id !== null
                    ? "outside_player_id"
                    : "tournament_team_player_id";

        const identityValue =
            player.user_id ??
            player.outside_player_id ??
            player.tournament_team_player_id;

        const [duplicate] = await connection.execute(
            `SELECT id
             FROM cst_match_players
             WHERE match_id = ?
               AND ${identityColumn} = ?
             LIMIT 1`,
            [matchId, identityValue]
        );

        if (duplicate.length) {
            await connection.rollback();

            return NextResponse.json(
                {
                    success: false,
                    message: "This player is already added to this match.",
                },
                { status: 409 }
            );
        }

        // At most 11 active playing-eleven players per team.
        if (selection.data.playing_11) {
            const [playingEleven] = await connection.execute(
                `SELECT COUNT(*) AS total
                 FROM cst_match_players
                 WHERE match_id = ?
                   AND team_id = ?
                   AND playing_11 = 1
                   AND status = 1`,
                [matchId, teamId]
            );

            if (Number(playingEleven[0].total) >= 11) {
                await connection.rollback();

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "This team already has 11 players in the playing eleven.",
                    },
                    { status: 400 }
                );
            }
        }

        // Enforce one captain and one vice-captain per team.
        for (const role of ["captain", "vice_captain"]) {
            if (selection.data[role]) {
                const [existing] = await connection.execute(
                    `SELECT id
                     FROM cst_match_players
                     WHERE match_id = ?
                       AND team_id = ?
                       AND ${role} = 1
                       AND status = 1
                     LIMIT 1`,
                    [matchId, teamId]
                );

                if (existing.length) {
                    await connection.rollback();

                    return NextResponse.json(
                        {
                            success: false,
                            message: `This team already has a ${role.replace("_", " ")}.`,
                        },
                        { status: 409 }
                    );
                }
            }
        }

        const [result] = await connection.execute(
            `INSERT INTO cst_match_players (
                match_id,
                team_id,
                user_id,
                outside_player_id,
                tournament_team_player_id,
                jersey_no,
                playing_11,
                substitute,
                captain,
                vice_captain,
                wicket_keeper,
                status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [
                matchId,
                teamId,
                player.user_id,
                player.outside_player_id,
                player.tournament_team_player_id,
                selection.data.jersey_no,
                selection.data.playing_11,
                selection.data.substitute,
                selection.data.captain,
                selection.data.vice_captain,
                selection.data.wicket_keeper,
                selection.data.status,
            ]
        );

        await connection.commit();

        return NextResponse.json(
            {
                success: true,
                message: "Match player added successfully.",
                id: result.insertId,
            },
            { status: 201 }
        );
    } catch (error) {
        if (connection) await connection.rollback();

        console.error("POST match player error:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to add match player.",
            },
            { status: 500 }
        );
    } finally {
        if (connection) connection.release();
    }
}