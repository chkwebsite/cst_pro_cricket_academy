import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import fs from "fs/promises";
import path from "path";
import pool from "@/app/components/lib/db";


// =====================================================
// GET SINGLE USER
// =====================================================

export async function GET(
    request,
    { params }
) {

    const connection =
        await pool.getConnection();

    try {

        const { id } = await params;


        const [rows] =
            await connection.query(
                `
SELECT
u.id,
    u.appointment_no,
    u.academy_id,
    a.academy_name,

    u.branch_id,
    b.branch_name,

    u.first_name,
    u.last_name,
    u.email,
    u.phone,
    u.profile_image,
    u.user_type,
    u.status,
    u.is_deleted,
    u.last_login_at,
    u.created_at,
    u.updated_at

                FROM cst_users u

                LEFT JOIN cst_academy a
                    ON a.id = u.academy_id

                LEFT JOIN cst_branch b
                    ON b.id = u.branch_id

                WHERE u.id = ?
    AND u.is_deleted = 0

                LIMIT 1
    `,
                [id]
            );


        if (rows.length === 0) {

            return NextResponse.json({
                success: false,
                message: "User not found"
            }, {
                status: 404
            });

        }


        return NextResponse.json({

            success: true,

            message: "User fetched successfully",

            data: rows[0]

        });


    } catch (error) {

        console.error(
            "Get Single User Error:",
            error
        );


        return NextResponse.json({

            success: false,

            message: "Failed to fetch user",

            error:
                process.env.NODE_ENV === "development"
                    ? error.message
                    : undefined

        }, {
            status: 500
        });


    } finally {

        connection.release();

    }
}


// =====================================================
// PUT - UPDATE USER
// =====================================================

export async function PUT(
    request,
    { params }
) {

    const connection =
        await pool.getConnection();

    let uploadedFilePath = null;
    let oldImage = null;

    try {

        const { id } = await params;


        // =====================================================
        // FORM DATA
        // =====================================================

        const formData =
            await request.formData();


        const appointment_no =
            formData.get("appointment_no")
                ?.toString()
                .trim();

        const academy_id =
            formData.get("academy_id") || null;

        const branch_id =
            formData.get("branch_id") || null;

        const first_name =
            formData.get("first_name")
                ?.toString()
                .trim();

        const last_name =
            formData.get("last_name")
                ?.toString()
                .trim() || null;

        const email =
            formData.get("email")
                ?.toString()
                .trim() || null;

        const phone =
            formData.get("phone")
                ?.toString()
                .trim() || null;

        const password =
            formData.get("password")
                ?.toString() || "";

        const user_type =
            formData.get("user_type")
                ?.toString()
                .trim();

        const status =
            formData.get("status") !== null
                ? Number(formData.get("status"))
                : 1;

        const profile_image =
            formData.get("profile_image");


        // =====================================================
        // GET OLD USER
        // =====================================================

        const [oldUsers] =
            await connection.query(
                `
SELECT *
    FROM cst_users
                WHERE id = ?
    AND is_deleted = 0
                LIMIT 1
    `,
                [id]
            );


        if (oldUsers.length === 0) {

            return NextResponse.json({
                success: false,
                message: "User not found"
            }, {
                status: 404
            });

        }


        const oldUser =
            oldUsers[0];

        oldImage =
            oldUser.profile_image;


        // =====================================================
        // VALIDATION
        // =====================================================

        if (!appointment_no) {

            return NextResponse.json({
                success: false,
                message:
                    "Appointment number is required"
            }, {
                status: 400
            });

        }

        if (!first_name) {

            return NextResponse.json({
                success: false,
                message:
                    "First name is required"
            }, {
                status: 400
            });

        }

        if (!user_type) {

            return NextResponse.json({
                success: false,
                message:
                    "User type is required"
            }, {
                status: 400
            });

        }


        // =====================================================
        // CHECK APPOINTMENT NUMBER
        // =====================================================

        const [duplicateAppointment] =
            await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE appointment_no = ?
    AND id != ?
        LIMIT 1
            `,
                [
                    appointment_no,
                    id
                ]
            );


        if (
            duplicateAppointment.length > 0
        ) {

            return NextResponse.json({
                success: false,
                message:
                    "Appointment number already exists"
            }, {
                status: 409
            });

        }


        // =====================================================
        // CHECK EMAIL
        // =====================================================

        if (email) {

            const [duplicateEmail] =
                await connection.query(
                    `
                    SELECT id
                    FROM cst_users
                    WHERE email = ?
    AND id != ?
        LIMIT 1
                    `,
                    [
                        email,
                        id
                    ]
                );


            if (
                duplicateEmail.length > 0
            ) {

                return NextResponse.json({
                    success: false,
                    message:
                        "Email already exists"
                }, {
                    status: 409
                });

            }

        }


        // =====================================================
        // IMAGE UPLOAD
        // =====================================================

        let imageName =
            oldUser.profile_image;


        if (
            profile_image &&
            typeof profile_image === "object" &&
            profile_image.size > 0
        ) {

            const allowedTypes = [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/webp"
            ];


            if (
                !allowedTypes.includes(
                    profile_image.type
                )
            ) {

                return NextResponse.json({
                    success: false,
                    message:
                        "Only JPG, JPEG, PNG and WEBP images are allowed"
                }, {
                    status: 400
                });

            }


            if (
                profile_image.size >
                5 * 1024 * 1024
            ) {

                return NextResponse.json({
                    success: false,
                    message:
                        "Image size must be less than 5MB"
                }, {
                    status: 400
                });

            }


            const uploadDir =
                path.join(
                    process.cwd(),
                    "public",
                    "uploads",
                    "users"
                );


            await fs.mkdir(
                uploadDir,
                { recursive: true }
            );


            const extension =
                path.extname(
                    profile_image.name
                ) || ".jpg";


            imageName =
                `${Date.now()} -${Math.round(
                    Math.random() * 1000000
                )
                }${extension.toLowerCase()} `;


            uploadedFilePath =
                path.join(
                    uploadDir,
                    imageName
                );


            const bytes =
                await profile_image.arrayBuffer();


            const buffer =
                Buffer.from(bytes);


            await fs.writeFile(
                uploadedFilePath,
                buffer
            );

        }


        // =====================================================
        // PASSWORD
        // =====================================================

        let passwordValue =
            oldUser.password;


        if (password) {

            passwordValue =
                await bcrypt.hash(
                    password,
                    10
                );

        }


        // =====================================================
        // TRANSACTION
        // =====================================================

        await connection.beginTransaction();


        // =====================================================
        // UPDATE USER
        // =====================================================

        await connection.query(
            `
            UPDATE cst_users
SET
appointment_no = ?,
    academy_id = ?,
    branch_id = ?,
    first_name = ?,
    last_name = ?,
    email = ?,
    phone = ?,
    password = ?,
    profile_image = ?,
    user_type = ?,
    status = ?

        WHERE id = ?
            `,
            [
                appointment_no,
                academy_id,
                branch_id,
                first_name,
                last_name,
                email,
                phone,
                passwordValue,
                imageName,
                user_type,
                status,
                id
            ]
        );


        // =====================================================
        // OLD MAPPING CLEANUP
        // =====================================================

        if (
            oldUser.user_type?.toLowerCase() ===
            "player"
        ) {

            await connection.query(
                `
                UPDATE cst_admission_players
                SET user_id = NULL
                WHERE user_id = ?
    `,
                [id]
            );


            await connection.query(
                `
                UPDATE cst_user_programs
                SET user_id = NULL
                WHERE user_id = ?
    `,
                [id]
            );

        }


        // =====================================================
        // NEW PLAYER MAPPING
        // =====================================================

        if (
            user_type.toLowerCase() ===
            "player"
        ) {

            const [playerRows] =
                await connection.query(
                    `
                    SELECT
id,
    admission_no,
    user_id

                    FROM cst_admission_players

                    WHERE admission_no = ?

    AND is_deleted = 0

                    LIMIT 1
    `,
                    [appointment_no]
                );


            if (playerRows.length === 0) {

                throw new Error(
                    "Player admission not found for this appointment number"
                );

            }


            const player =
                playerRows[0];


            if (
                player.user_id !== null &&
                Number(player.user_id) !==
                Number(id)
            ) {

                throw new Error(
                    "This player is already linked with another user"
                );

            }


            // -------------------------------------------------
            // UPDATE PLAYER
            // -------------------------------------------------

            await connection.query(
                `
                UPDATE cst_admission_players

                SET user_id = ?

    WHERE id = ?
        `,
                [
                    id,
                    player.id
                ]
            );


            // -------------------------------------------------
            // UPDATE PROGRAMS
            // -------------------------------------------------

            await connection.query(
                `
                UPDATE cst_user_programs

                SET user_id = ?

    WHERE admission_players_id = ?

        AND is_deleted = 0
            `,
                [
                    id,
                    player.id
                ]
            );

        }


        // =====================================================
        // UPDATE USER BRANCH
        // =====================================================

        await connection.query(
            `
            UPDATE cst_user_branches
            SET user_id = ?
    WHERE user_id = ?
        `,
            [
                id,
                id
            ]
        );


        // =====================================================
        // COMMIT
        // =====================================================

        await connection.commit();


        // =====================================================
        // DELETE OLD IMAGE
        // =====================================================

        if (
            uploadedFilePath &&
            oldImage
        ) {

            try {

                const oldImagePath =
                    path.join(
                        process.cwd(),
                        "public",
                        oldImage.startsWith("/")
                            ? oldImage.substring(1)
                            : oldImage
                    );

                await fs.unlink(
                    oldImagePath
                );

            } catch { }

        }


        return NextResponse.json({

            success: true,

            message:
                "User updated successfully",

            data: {
                id,
                appointment_no,
                profile_image:
                    imageName
                        ? `/ uploads / users / ${imageName} `
                        : null
            }

        });


    } catch (error) {

        await connection.rollback();


        if (uploadedFilePath) {

            try {

                await fs.unlink(
                    uploadedFilePath
                );

            } catch { }

        }


        console.error(
            "Update User Error:",
            error
        );


        return NextResponse.json({

            success: false,

            message:
                error.message ||
                "Failed to update user",

            error:
                process.env.NODE_ENV === "development"
                    ? error.message
                    : undefined

        }, {
            status: 500
        });


    } finally {

        connection.release();

    }
}