import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

// =====================================================
// GET ALL PROGRAMS
// =====================================================
export async function GET(request) {
    const connection = await pool.getConnection();

    try {
        const { searchParams } = new URL(request.url);

        const academy_id = searchParams.get("academy_id");
        const branch_id = searchParams.get("branch_id");
        const status = searchParams.get("status");

        let sql = `
SELECT
p.id,
    p.academy_id,
    a.academy_name,

    p.branch_id,
    b.branch_name,

    p.program_name,
    p.program_code,
    p.description,

    p.program_fee,
    p.registration_fee,
    p.daily_fee,
    p.kit_fee,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_programs p

            INNER JOIN cst_academy a
                ON a.id = p.academy_id

            LEFT JOIN cst_branch b
                ON b.id = p.branch_id

            WHERE p.is_deleted = 0
    `;

        const values = [];

        // Academy filter
        if (academy_id) {
            sql += ` AND p.academy_id = ? `;
            values.push(academy_id);
        }

        // Branch filter
        if (branch_id) {
            sql += ` AND p.branch_id = ? `;
            values.push(branch_id);
        }

        // Status filter
        if (status !== null && status !== "") {
            sql += ` AND p.status = ? `;
            values.push(status);
        }

        sql += ` ORDER BY p.id DESC`;

        const [rows] = await connection.query(sql, values);

        return NextResponse.json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {
        console.error("GET PROGRAMS ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to fetch programs"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}


// =====================================================
// CREATE PROGRAM
// =====================================================
export async function POST(request) {
    const connection = await pool.getConnection();

    try {
        const body = await request.json();

        const {
            academy_id,
            branch_id,
            program_name,
            program_code,
            description,
            program_fee,
            registration_fee,
            daily_fee,
            kit_fee,
            status
        } = body;


        // =================================================
        // VALIDATION
        // =================================================

        if (!academy_id) {
            return NextResponse.json({
                success: false,
                message: "Academy ID is required"
            }, { status: 400 });
        }

        if (!program_name || !program_name.trim()) {
            return NextResponse.json({
                success: false,
                message: "Program name is required"
            }, { status: 400 });
        }


        // =================================================
        // CHECK ACADEMY
        // =================================================

        const [academy] = await connection.query(
            `
            SELECT id
            FROM cst_academy
            WHERE id = ?
    AND status = 1
            AND is_deleted = 0
            LIMIT 1
    `,
            [academy_id]
        );

        if (academy.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Academy not found"
            }, { status: 404 });
        }


        // =================================================
        // CHECK BRANCH
        // =================================================

        if (branch_id) {

            const [branch] = await connection.query(
                `
                SELECT id
                FROM cst_branch
                WHERE id = ?
    AND academy_id = ?
        AND status = 1
                AND is_deleted = 0
                LIMIT 1
    `,
                [
                    branch_id,
                    academy_id
                ]
            );

            if (branch.length === 0) {
                return NextResponse.json({
                    success: false,
                    message: "Branch does not belong to this academy"
                }, { status: 400 });
            }
        }


        // =================================================
        // CHECK PROGRAM CODE
        // =================================================

        if (program_code) {

            const [existingCode] = await connection.query(
                `
                SELECT id
                FROM cst_programs
                WHERE academy_id = ?
    AND program_code = ?
        AND is_deleted = 0
                LIMIT 1
    `,
                [
                    academy_id,
                    program_code
                ]
            );

            if (existingCode.length > 0) {
                return NextResponse.json({
                    success: false,
                    message: "Program code already exists"
                }, { status: 409 });
            }
        }


        // =================================================
        // INSERT PROGRAM
        // =================================================

        const [result] = await connection.query(
            `
            INSERT INTO cst_programs
    (
        academy_id,
        branch_id,
        program_name,
        program_code,
        description,
        program_fee,
        registration_fee,
        daily_fee,
        kit_fee,
        status
    )
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
            [
                academy_id,
                branch_id || null,
                program_name.trim(),
                program_code || null,
                description || null,
                program_fee ?? 0,
                registration_fee ?? 0,
                daily_fee ?? 0,
                kit_fee ?? 0,
                status ?? 1
            ]
        );


        // =================================================
        // GET CREATED PROGRAM
        // =================================================

        const [rows] = await connection.query(
            `
SELECT
p.id,
    p.academy_id,
    a.academy_name,

    p.branch_id,
    b.branch_name,

    p.program_name,
    p.program_code,
    p.description,

    p.program_fee,
    p.registration_fee,
    p.daily_fee,
    p.kit_fee,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_programs p

            INNER JOIN cst_academy a
                ON a.id = p.academy_id

            LEFT JOIN cst_branch b
                ON b.id = p.branch_id

            WHERE p.id = ?
    LIMIT 1
        `,
            [result.insertId]
        );


        return NextResponse.json({
            success: true,
            message: "Program created successfully",
            data: rows[0]
        }, { status: 201 });


    } catch (error) {
        console.error("CREATE PROGRAM ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to create program"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}
