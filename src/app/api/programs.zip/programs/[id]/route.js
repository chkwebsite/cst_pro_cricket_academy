import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";


// =====================================================
// GET SINGLE PROGRAM
// =====================================================
export async function GET(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;

        if (!id) {
            return NextResponse.json({
                success: false,
                message: "Program ID is required"
            }, { status: 400 });
        }


        const [rows] = await connection.query(
            `
SELECT
p.id,
    p.academy_id,
    a.academy_name,

    p.branch_id,
    b.branch_name,

    p.program_name,
    p.program_code,
    p.description,

    p.program_fee,
    p.registration_fee,
    p.daily_fee,
    p.kit_fee,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_programs p

            INNER JOIN cst_academy a
                ON a.id = p.academy_id

            LEFT JOIN cst_branch b
                ON b.id = p.branch_id

            WHERE p.id = ?
    AND p.is_deleted = 0

            LIMIT 1
    `,
            [id]
        );


        if (rows.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Program not found"
            }, { status: 404 });
        }


        return NextResponse.json({
            success: true,
            data: rows[0]
        });


    } catch (error) {
        console.error("GET SINGLE PROGRAM ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to fetch program"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}



// =====================================================
// UPDATE PROGRAM
// =====================================================
export async function PUT(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;

        const body = await request.json();

        const {
            academy_id,
            branch_id,
            program_name,
            program_code,
            description,
            program_fee,
            registration_fee,
            daily_fee,
            kit_fee,
            status
        } = body;


        // =================================================
        // VALIDATION
        // =================================================

        if (!id) {
            return NextResponse.json({
                success: false,
                message: "Program ID is required"
            }, { status: 400 });
        }

        if (!academy_id) {
            return NextResponse.json({
                success: false,
                message: "Academy ID is required"
            }, { status: 400 });
        }

        if (!program_name || !program_name.trim()) {
            return NextResponse.json({
                success: false,
                message: "Program name is required"
            }, { status: 400 });
        }


        // =================================================
        // CHECK PROGRAM
        // =================================================

        const [existingProgram] = await connection.query(
            `
            SELECT id
            FROM cst_programs
            WHERE id = ?
    AND is_deleted = 0
            LIMIT 1
    `,
            [id]
        );


        if (existingProgram.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Program not found"
            }, { status: 404 });
        }


        // =================================================
        // CHECK ACADEMY
        // =================================================

        const [academy] = await connection.query(
            `
            SELECT id
            FROM cst_academy
            WHERE id = ?
    AND status = 1
            AND is_deleted = 0
            LIMIT 1
    `,
            [academy_id]
        );


        if (academy.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Academy not found"
            }, { status: 404 });
        }


        // =================================================
        // CHECK BRANCH
        // =================================================

        if (branch_id) {

            const [branch] = await connection.query(
                `
                SELECT id
                FROM cst_branch
                WHERE id = ?
    AND academy_id = ?
        AND status = 1
                AND is_deleted = 0
                LIMIT 1
    `,
                [
                    branch_id,
                    academy_id
                ]
            );


            if (branch.length === 0) {
                return NextResponse.json({
                    success: false,
                    message: "Branch does not belong to this academy"
                }, { status: 400 });
            }
        }


        // =================================================
        // CHECK DUPLICATE PROGRAM CODE
        // =================================================

        if (program_code) {

            const [duplicateCode] = await connection.query(
                `
                SELECT id
                FROM cst_programs
                WHERE academy_id = ?
    AND program_code = ?
        AND id != ?
            AND is_deleted = 0
                LIMIT 1
    `,
                [
                    academy_id,
                    program_code,
                    id
                ]
            );


            if (duplicateCode.length > 0) {
                return NextResponse.json({
                    success: false,
                    message: "Program code already exists"
                }, { status: 409 });
            }
        }


        // =================================================
        // UPDATE
        // =================================================

        await connection.query(
            `
            UPDATE cst_programs
SET
academy_id = ?,
    branch_id = ?,
    program_name = ?,
    program_code = ?,
    description = ?,
    program_fee = ?,
    registration_fee = ?,
    daily_fee = ?,
    kit_fee = ?,
    status = ?
        WHERE id = ?
            `,
            [
                academy_id,
                branch_id || null,
                program_name.trim(),
                program_code || null,
                description || null,
                program_fee ?? 0,
                registration_fee ?? 0,
                daily_fee ?? 0,
                kit_fee ?? 0,
                status ?? 1,
                id
            ]
        );


        // =================================================
        // GET UPDATED PROGRAM
        // =================================================

        const [rows] = await connection.query(
            `
            SELECT
p.id,
    p.academy_id,
    a.academy_name,

    p.branch_id,
    b.branch_name,

    p.program_name,
    p.program_code,
    p.description,

    p.program_fee,
    p.registration_fee,
    p.daily_fee,
    p.kit_fee,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_programs p

            INNER JOIN cst_academy a
                ON a.id = p.academy_id

            LEFT JOIN cst_branch b
                ON b.id = p.branch_id

            WHERE p.id = ?

    LIMIT 1
        `,
            [id]
        );


        return NextResponse.json({
            success: true,
            message: "Program updated successfully",
            data: rows[0]
        });


    } catch (error) {
        console.error("UPDATE PROGRAM ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to update program"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}



// =====================================================
// DELETE PROGRAM - SOFT DELETE
// =====================================================
export async function DELETE(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;


        if (!id) {
            return NextResponse.json({
                success: false,
                message: "Program ID is required"
            }, { status: 400 });
        }


        // =================================================
        // CHECK PROGRAM
        // =================================================

        const [existingProgram] = await connection.query(
            `
            SELECT id
            FROM cst_programs
            WHERE id = ?
    AND is_deleted = 0
            LIMIT 1
    `,
            [id]
        );


        if (existingProgram.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Program not found"
            }, { status: 404 });
        }


        // =================================================
        // SOFT DELETE
        // =================================================

        await connection.query(
            `
            UPDATE cst_programs
SET
is_deleted = 1,
    status = 0
            WHERE id = ?
    `,
            [id]
        );


        return NextResponse.json({
            success: true,
            message: "Program deleted successfully"
        });


    } catch (error) {
        console.error("DELETE PROGRAM ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to delete program"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}