import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import pool from "@/app/components/lib/db";

import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

// =====================================================
// DELETE FILE HELPER
// =====================================================

async function deleteFile(filePath) {
    if (!filePath) return;

    try {
        const fullPath = path.join(
            process.cwd(),
            "public",
            filePath
        );

        await fs.unlink(fullPath);
    } catch (error) {
        // File does not exist
    }
}


// =====================================================
// POST
// =====================================================

export async function POST(request) {

    const connection = await pool.getConnection();

    let profileImagePath = null;

    try {

        // =================================================
        // FORM DATA
        // =================================================

        const formData = await request.formData();

        const apointment_no =
            formData.get("apointment_no");

        const first_name =
            formData.get("first_name");

        const last_name =
            formData.get("last_name");

        const email =
            formData.get("email");

        const phone =
            formData.get("phone");

        const password =
            formData.get("password");

        const user_type =
            formData.get("user_type");

        const status =
            formData.get("status");

        const profileImage =
            formData.get("profile_image");


        // =================================================
        // VALIDATION
        // =================================================

        if (!apointment_no) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Apointment number is required"
                },
                { status: 400 }
            );
        }

        if (!first_name) {
            return NextResponse.json(
                {
                    success: false,
                    message: "First name is required"
                },
                { status: 400 }
            );
        }

        if (!password) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Password is required"
                },
                { status: 400 }
            );
        }

        if (!user_type) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User type is required"
                },
                { status: 400 }
            );
        }

        if (
            !["admin", "staff", "player"].includes(
                user_type
            )
        ) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid user type"
                },
                { status: 400 }
            );
        }


        // =================================================
        // PROFILE IMAGE
        // =================================================

        if (
            profileImage &&
            typeof profileImage === "object" &&
            profileImage.size > 0
        ) {

            // 5 MB
            const maxSize =
                5 * 1024 * 1024;

            if (profileImage.size > maxSize) {

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Profile image must be less than 5 MB"
                    },
                    { status: 400 }
                );
            }


            // Allowed image types

            const allowedTypes = [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/webp"
            ];

            if (
                !allowedTypes.includes(
                    profileImage.type
                )
            ) {

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Only JPG, JPEG, PNG and WEBP images are allowed"
                    },
                    { status: 400 }
                );
            }


            // =================================================
            // UPLOAD DIRECTORY
            // =================================================

            const uploadDir =
                path.join(
                    process.cwd(),
                    "public",
                    "uploads",
                    "users"
                );

            await fs.mkdir(
                uploadDir,
                {
                    recursive: true
                }
            );


            // =================================================
            // EXTENSION
            // =================================================

            const extensionMap = {
                "image/jpeg": "jpg",
                "image/jpg": "jpg",
                "image/png": "png",
                "image/webp": "webp"
            };

            const extension =
                extensionMap[
                profileImage.type
                ];


            // =================================================
            // UNIQUE FILE NAME
            // =================================================

            const fileName =
                `${Date.now()} -${crypto
                    .randomBytes(6)
                    .toString("hex")
                }.${extension} `;

            const filePath =
                path.join(
                    uploadDir,
                    fileName
                );


            // =================================================
            // SAVE IMAGE
            // =================================================

            const bytes =
                await profileImage.arrayBuffer();

            const buffer =
                Buffer.from(bytes);

            await fs.writeFile(
                filePath,
                buffer
            );


            profileImagePath =
                `/ uploads / users / ${fileName} `;
        }


        // =================================================
        // START TRANSACTION
        // =================================================

        await connection.beginTransaction();


        // =================================================
        // CHECK APPOINTMENT NUMBER
        // =================================================

        const [existingAppointment] =
            await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE apointment_no = ?
    LIMIT 1
        `,
                [apointment_no]
            );

        if (
            existingAppointment.length > 0
        ) {

            await connection.rollback();

            if (profileImagePath) {
                await deleteFile(
                    profileImagePath
                );
            }

            return NextResponse.json(
                {
                    success: false,
                    message:
                        "Apointment number already exists"
                },
                { status: 409 }
            );
        }


        // =================================================
        // CHECK EMAIL
        // =================================================

        if (email) {

            const [existingEmail] =
                await connection.query(
                    `
                    SELECT id
                    FROM cst_users
                    WHERE email = ?
    LIMIT 1
        `,
                    [email]
                );

            if (
                existingEmail.length > 0
            ) {

                await connection.rollback();

                if (profileImagePath) {
                    await deleteFile(
                        profileImagePath
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Email already exists"
                    },
                    { status: 409 }
                );
            }
        }


        // =================================================
        // PASSWORD HASH
        // =================================================

        const hashedPassword =
            await bcrypt.hash(
                password,
                10
            );


        // =================================================
        // INSERT USER
        // =================================================

        const [userResult] =
            await connection.query(
                `
                INSERT INTO cst_users
    (
        apointment_no,
        first_name,
        last_name,
        email,
        phone,
        password,
        profile_image,
        user_type,
        status
    )
VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)
    `,
                [
                    apointment_no,
                    first_name,
                    last_name || null,
                    email || null,
                    phone || null,
                    hashedPassword,
                    profileImagePath,
                    user_type,
                    status !== null
                        ? Number(status)
                        : 1
                ]
            );


        const userId =
            userResult.insertId;


        // =================================================
        // ADMIN / STAFF
        // =================================================

        if (
            user_type === "admin" ||
            user_type === "staff"
        ) {

            // -------------------------------------------------
            // Find staff using apointment_no
            // -------------------------------------------------

            const [staffRows] =
                await connection.query(
                    `
SELECT
id,
    user_id
                    FROM cst_staff
                    WHERE apointment_no = ?
    AND is_deleted = 0
                    LIMIT 1
    `,
                    [apointment_no]
                );


            if (staffRows.length === 0) {

                await connection.rollback();

                if (profileImagePath) {
                    await deleteFile(
                        profileImagePath
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Staff record not found for this apointment number"
                    },
                    { status: 404 }
                );
            }


            // -------------------------------------------------
            // Already linked
            // -------------------------------------------------

            if (staffRows[0].user_id) {

                await connection.rollback();

                if (profileImagePath) {
                    await deleteFile(
                        profileImagePath
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "This staff is already linked with a user"
                    },
                    { status: 409 }
                );
            }


            // -------------------------------------------------
            // UPDATE STAFF
            // -------------------------------------------------

            await connection.query(
                `
                UPDATE cst_staff
                SET user_id = ?
    WHERE id = ?
        `,
                [
                    userId,
                    staffRows[0].id
                ]
            );
        }


        // =================================================
        // PLAYER
        // =================================================

        if (
            user_type === "player"
        ) {

            // -------------------------------------------------
            // Find player using admission_no
            // -------------------------------------------------

            const [playerRows] =
                await connection.query(
                    `
                    SELECT
id,
    user_id
                    FROM cst_admission_players
                    WHERE admission_no = ?
    AND is_deleted = 0
                    LIMIT 1
    `,
                    [apointment_no]
                );


            if (playerRows.length === 0) {

                await connection.rollback();

                if (profileImagePath) {
                    await deleteFile(
                        profileImagePath
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Admission player not found for this apointment number"
                    },
                    { status: 404 }
                );
            }


            // -------------------------------------------------
            // Already linked
            // -------------------------------------------------

            if (playerRows[0].user_id) {

                await connection.rollback();

                if (profileImagePath) {
                    await deleteFile(
                        profileImagePath
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "This player is already linked with a user"
                    },
                    { status: 409 }
                );
            }


            const playerId =
                playerRows[0].id;


            // =================================================
            // UPDATE ADMISSION PLAYER
            // =================================================

            await connection.query(
                `
                UPDATE cst_admission_players
                SET user_id = ?
    WHERE id = ?
        `,
                [
                    userId,
                    playerId
                ]
            );


            // =================================================
            // UPDATE USER PROGRAMS
            // =================================================

            await connection.query(
                `
                UPDATE cst_user_programs
                SET user_id = ?
    WHERE admission_players_id = ?
        AND is_deleted = 0
            `,
                [
                    userId,
                    playerId
                ]
            );
        }


        // =================================================
        // COMMIT
        // =================================================

        await connection.commit();


        // =================================================
        // RESPONSE
        // =================================================

        return NextResponse.json(
            {
                success: true,
                message:
                    "User created and linked successfully",

                data: {
                    id: userId,
                    apointment_no,
                    first_name,
                    last_name:
                        last_name || null,
                    email:
                        email || null,
                    phone:
                        phone || null,
                    profile_image:
                        profileImagePath,
                    user_type,
                    status:
                        status !== null
                            ? Number(status)
                            : 1
                }
            },
            { status: 201 }
        );


    } catch (error) {

        // =================================================
        // ROLLBACK
        // =================================================

        await connection.rollback();


        // Delete uploaded image
        if (profileImagePath) {
            await deleteFile(
                profileImagePath
            );
        }


        console.error(
            "USER POST ERROR:",
            error
        );


        return NextResponse.json(
            {
                success: false,
                message:
                    "Failed to create user",
                error:
                    error.message
            },
            { status: 500 }
        );


    } finally {

        connection.release();
    }
}