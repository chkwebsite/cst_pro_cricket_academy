import { NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import pool from "@/app/components/lib/db";

import fs from "fs/promises";
import path from "path";
import crypto from "crypto";

// =====================================================
// HELPER: DELETE FILE
// =====================================================

async function deleteFile(filePath) {
    if (!filePath) return;

    try {
        const fullPath = path.join(
            process.cwd(),
            "public",
            filePath
        );

        await fs.unlink(fullPath);
    } catch (error) {
        // File already doesn't exist
    }
}

// =====================================================
// PUT - UPDATE USER
// =====================================================

export async function PUT(request, { params }) {

    const connection = await pool.getConnection();

    let newProfileImage = null;

    try {

        const { id } = await params;

        if (!id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User ID is required"
                },
                { status: 400 }
            );
        }

        // =====================================================
        // FORM DATA
        // =====================================================

        const formData = await request.formData();

        const first_name = formData.get("first_name");
        const last_name = formData.get("last_name");
        const email = formData.get("email");
        const phone = formData.get("phone");
        const password = formData.get("password");
        const user_type = formData.get("user_type");
        const status = formData.get("status");

        const staff_id = formData.get("staff_id");
        const admission_players_id =
            formData.get("admission_players_id");

        const profileImage =
            formData.get("profile_image");

        // =====================================================
        // VALIDATION
        // =====================================================

        if (!first_name) {
            return NextResponse.json(
                {
                    success: false,
                    message: "First name is required"
                },
                { status: 400 }
            );
        }

        if (!user_type) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User type is required"
                },
                { status: 400 }
            );
        }

        if (
            !["admin", "staff", "player"].includes(user_type)
        ) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid user type"
                },
                { status: 400 }
            );
        }

        // =====================================================
        // GET EXISTING USER
        // =====================================================

        const [users] = await connection.query(
            `
SELECT
id,
    first_name,
    last_name,
    email,
    phone,
    password,
    profile_image,
    user_type,
    status
            FROM cst_users
            WHERE id = ?
    AND is_deleted = 0
            LIMIT 1
    `,
            [id]
        );

        if (users.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User not found"
                },
                { status: 404 }
            );
        }

        const oldUser = users[0];

        // =====================================================
        // CHECK EMAIL
        // =====================================================

        if (email) {

            const [emailRows] = await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE email = ?
    AND id != ?
        AND is_deleted = 0
                LIMIT 1
                `,
                [email, id]
            );

            if (emailRows.length > 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "Email already exists"
                    },
                    { status: 409 }
                );
            }
        }

        // =====================================================
        // START TRANSACTION
        // =====================================================

        await connection.beginTransaction();

        // =====================================================
        // PROFILE IMAGE
        // =====================================================

        let profileImagePath =
            oldUser.profile_image;

        if (
            profileImage &&
            typeof profileImage === "object" &&
            profileImage.size > 0
        ) {

            // 5 MB
            const maxSize =
                5 * 1024 * 1024;

            if (profileImage.size > maxSize) {

                await connection.rollback();

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Profile image must be less than 5 MB"
                    },
                    { status: 400 }
                );
            }

            const allowedTypes = [
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/webp"
            ];

            if (!allowedTypes.includes(profileImage.type)) {

                await connection.rollback();

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Only JPG, JPEG, PNG and WEBP images are allowed"
                    },
                    { status: 400 }
                );
            }

            // =================================================
            // UPLOAD DIRECTORY
            // =================================================

            const uploadDir = path.join(
                process.cwd(),
                "public",
                "uploads",
                "users"
            );

            await fs.mkdir(
                uploadDir,
                {
                    recursive: true
                }
            );

            // =================================================
            // EXTENSION
            // =================================================

            const extensionMap = {
                "image/jpeg": "jpg",
                "image/jpg": "jpg",
                "image/png": "png",
                "image/webp": "webp"
            };

            const extension =
                extensionMap[profileImage.type];

            // =================================================
            // UNIQUE NAME
            // =================================================

            const fileName =
                `${Date.now()} -${crypto
                    .randomBytes(6)
                    .toString("hex")
                }.${extension} `;

            const filePath = path.join(
                uploadDir,
                fileName
            );

            const bytes =
                await profileImage.arrayBuffer();

            const buffer =
                Buffer.from(bytes);

            await fs.writeFile(
                filePath,
                buffer
            );

            newProfileImage =
                `/ uploads / users / ${fileName} `;

            profileImagePath =
                newProfileImage;
        }

        // =====================================================
        // PASSWORD
        // =====================================================

        let hashedPassword =
            oldUser.password;

        if (password) {

            hashedPassword =
                await bcrypt.hash(
                    password,
                    10
                );
        }

        // =====================================================
        // UPDATE USER
        // =====================================================

        await connection.query(
            `
            UPDATE cst_users
SET
first_name = ?,
    last_name = ?,
    email = ?,
    phone = ?,
    password = ?,
    profile_image = ?,
    user_type = ?,
    status = ?
        WHERE id = ?
            `,
            [
                first_name,
                last_name || null,
                email || null,
                phone || null,
                hashedPassword,
                profileImagePath,
                user_type,
                status !== null
                    ? Number(status)
                    : oldUser.status,
                id
            ]
        );

        // =====================================================
        // USER TYPE CHANGED / OLD MAPPING REMOVE
        // =====================================================

        if (
            oldUser.user_type !== user_type
        ) {

            // -----------------------------------------------
            // OLD STAFF MAPPING REMOVE
            // -----------------------------------------------

            if (
                oldUser.user_type === "admin" ||
                oldUser.user_type === "staff"
            ) {

                await connection.query(
                    `
                    UPDATE cst_staff
                    SET user_id = NULL
                    WHERE user_id = ?
    `,
                    [id]
                );
            }

            // -----------------------------------------------
            // OLD PLAYER MAPPING REMOVE
            // -----------------------------------------------

            if (
                oldUser.user_type === "player"
            ) {

                await connection.query(
                    `
                    UPDATE cst_admission_players
                    SET user_id = NULL
                    WHERE user_id = ?
    `,
                    [id]
                );

                await connection.query(
                    `
                    UPDATE cst_user_programs
                    SET user_id = NULL
                    WHERE user_id = ?
    `,
                    [id]
                );
            }
        }

        // =====================================================
        // ADMIN / STAFF
        // =====================================================

        if (
            user_type === "admin" ||
            user_type === "staff"
        ) {

            if (!staff_id) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "staff_id is required for admin/staff user"
                    },
                    { status: 400 }
                );
            }

            // Check staff
            const [staffRows] =
                await connection.query(
                    `
                    SELECT
id,
    user_id
                    FROM cst_staff
                    WHERE id = ?
    AND is_deleted = 0
                    LIMIT 1
    `,
                    [staff_id]
                );

            if (staffRows.length === 0) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Staff record not found"
                    },
                    { status: 404 }
                );
            }

            // Another user already linked?
            if (
                staffRows[0].user_id &&
                Number(staffRows[0].user_id) !==
                Number(id)
            ) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "This staff record is already linked with another user"
                    },
                    { status: 409 }
                );
            }

            // Update staff
            await connection.query(
                `
                UPDATE cst_staff
                SET user_id = ?
    WHERE id = ?
        `,
                [
                    id,
                    staff_id
                ]
            );
        }

        // =====================================================
        // PLAYER
        // =====================================================

        if (user_type === "player") {

            if (!admission_players_id) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "admission_players_id is required for player user"
                    },
                    { status: 400 }
                );
            }

            // Check player
            const [playerRows] =
                await connection.query(
                    `
                    SELECT
id,
    user_id
                    FROM cst_admission_players
                    WHERE id = ?
    AND is_deleted = 0
                    LIMIT 1
    `,
                    [admission_players_id]
                );

            if (playerRows.length === 0) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "Admission player not found"
                    },
                    { status: 404 }
                );
            }

            // Another user already linked?
            if (
                playerRows[0].user_id &&
                Number(playerRows[0].user_id) !==
                Number(id)
            ) {

                await connection.rollback();

                if (newProfileImage) {
                    await deleteFile(
                        newProfileImage
                    );
                }

                return NextResponse.json(
                    {
                        success: false,
                        message:
                            "This player is already linked with another user"
                    },
                    { status: 409 }
                );
            }

            // Update admission player
            await connection.query(
                `
                UPDATE cst_admission_players
                SET user_id = ?
    WHERE id = ?
        `,
                [
                    id,
                    admission_players_id
                ]
            );

            // Update all player programs
            await connection.query(
                `
                UPDATE cst_user_programs
                SET user_id = ?
    WHERE admission_players_id = ?
        AND is_deleted = 0
            `,
                [
                    id,
                    admission_players_id
                ]
            );
        }

        // =====================================================
        // COMMIT
        // =====================================================

        await connection.commit();

        // =====================================================
        // DELETE OLD IMAGE
        // =====================================================

        if (
            newProfileImage &&
            oldUser.profile_image &&
            oldUser.profile_image !==
            newProfileImage
        ) {
            await deleteFile(
                oldUser.profile_image
            );
        }

        // =====================================================
        // RESPONSE
        // =====================================================

        return NextResponse.json(
            {
                success: true,
                message:
                    "User updated successfully",
                data: {
                    id: Number(id),
                    first_name,
                    last_name:
                        last_name || null,
                    email:
                        email || null,
                    phone:
                        phone || null,
                    profile_image:
                        profileImagePath,
                    user_type,
                    status:
                        status !== null
                            ? Number(status)
                            : oldUser.status
                }
            },
            { status: 200 }
        );

    } catch (error) {

        // =====================================================
        // ROLLBACK
        // =====================================================

        await connection.rollback();

        // Delete newly uploaded image
        if (newProfileImage) {
            await deleteFile(
                newProfileImage
            );
        }

        console.error(
            "USER UPDATE ERROR:",
            error
        );

        return NextResponse.json(
            {
                success: false,
                message:
                    "Failed to update user",
                error: error.message
            },
            { status: 500 }
        );

    } finally {

        connection.release();
    }
}


// =====================================================
// DELETE - SOFT DELETE USER
// =====================================================

export async function DELETE(
    request,
    { params }
) {

    const connection =
        await pool.getConnection();

    try {

        const { id } = await params;

        if (!id) {
            return NextResponse.json(
                {
                    success: false,
                    message:
                        "User ID is required"
                },
                { status: 400 }
            );
        }

        // =====================================================
        // GET USER
        // =====================================================

        const [users] =
            await connection.query(
                `
SELECT
id,
    profile_image,
    user_type
                FROM cst_users
                WHERE id = ?
    AND is_deleted = 0
                LIMIT 1
    `,
                [id]
            );

        if (users.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message:
                        "User not found"
                },
                { status: 404 }
            );
        }

        const user =
            users[0];

        // =====================================================
        // TRANSACTION
        // =====================================================

        await connection.beginTransaction();

        // =====================================================
        // SOFT DELETE USER
        // =====================================================

        await connection.query(
            `
            UPDATE cst_users
SET
is_deleted = 1,
    status = 0
            WHERE id = ?
    `,
            [id]
        );

        // =====================================================
        // ADMIN / STAFF
        // =====================================================

        if (
            user.user_type === "admin" ||
            user.user_type === "staff"
        ) {

            await connection.query(
                `
                UPDATE cst_staff
                SET user_id = NULL
                WHERE user_id = ?
    `,
                [id]
            );
        }

        // =====================================================
        // PLAYER
        // =====================================================

        if (
            user.user_type === "player"
        ) {

            await connection.query(
                `
                UPDATE cst_admission_players
                SET user_id = NULL
                WHERE user_id = ?
    `,
                [id]
            );

            await connection.query(
                `
                UPDATE cst_user_programs
                SET user_id = NULL
                WHERE user_id = ?
    `,
                [id]
            );
        }

        // =====================================================
        // COMMIT
        // =====================================================

        await connection.commit();

        // =====================================================
        // DELETE PROFILE IMAGE
        // =====================================================

        if (user.profile_image) {
            await deleteFile(
                user.profile_image
            );
        }

        // =====================================================
        // RESPONSE
        // =====================================================

        return NextResponse.json(
            {
                success: true,
                message:
                    "User deleted successfully"
            },
            { status: 200 }
        );

    } catch (error) {

        await connection.rollback();

        console.error(
            "USER DELETE ERROR:",
            error
        );

        return NextResponse.json(
            {
                success: false,
                message:
                    "Failed to delete user",
                error: error.message
            },
            { status: 500 }
        );

    } finally {

        connection.release();
    }
}