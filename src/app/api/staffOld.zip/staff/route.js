import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

// ======================================================
// GET ALL STAFF
// ======================================================

export async function GET(request) {
    const connection = await pool.getConnection();

    try {
        const { searchParams } = new URL(request.url);

        const branch_id = searchParams.get("branch_id");
        const role_id = searchParams.get("role_id");
        const status = searchParams.get("status");
        const search = searchParams.get("search");

        let where = `
            WHERE s.is_deleted = 0
    `;

        const params = [];

        // Branch filter
        if (branch_id) {
            where += ` AND s.branch_id = ? `;
            params.push(Number(branch_id));
        }

        // Role filter
        if (role_id) {
            where += ` AND s.role_id = ? `;
            params.push(Number(role_id));
        }

        // Status filter
        if (status !== null && status !== "") {
            where += ` AND s.status = ? `;
            params.push(Number(status));
        }

        // Search
        if (search) {
            where += `
                AND (
        s.appointment_no LIKE ?
        OR s.first_name LIKE ?
        OR s.last_name LIKE ?
        OR s.speciality LIKE ?
        OR s.qualification LIKE ?
                )
    `;

            const searchValue = `%${search}%`;

            params.push(
                searchValue,
                searchValue,
                searchValue,
                searchValue,
                searchValue
            );
        }

        const [rows] = await connection.query(
            `
SELECT
s.*,
    ac.academy_name,
    r.role_name,

    b.branch_name

            FROM cst_staff s

            LEFT JOIN cst_roles r
                ON r.id = s.role_id

            LEFT JOIN cst_branch b
                ON b.id = s.branch_id

            LEFT JOIN cst_academy ac 
                ON s.academy_id = ac.id
            ${where}

            ORDER BY s.id DESC
    `,
            params
        );

        return NextResponse.json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {

        console.error("GET STAFF ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to fetch staff"
            },
            { status: 500 }
        );

    } finally {
        connection.release();
    }
}


// ======================================================
// POST STAFF
// ======================================================

export async function POST(request) {
    const connection = await pool.getConnection();

    try {
        const body = await request.json();

        const {
            user_id,
            role_id,
            academy_id,
            branch_id,
            first_name,
            last_name,
            father_name,
            mother_name,
            gender,
            speciality,
            experience,
            previous_academy,
            previous_academy_duration,
            qualification,
            achievement,
            last_salary,
            current_salary,
            dob,
            date_of_joining,
            date_of_appointment,
            status
        } = body;


        // ==================================================
        // VALIDATION
        // ==================================================

        if (!role_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Role is required"
                },
                { status: 400 }
            );
        }

        if (!branch_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Branch is required"
                },
                { status: 400 }
            );
        }

        if (!first_name || !String(first_name).trim()) {
            return NextResponse.json(
                {
                    success: false,
                    message: "First name is required"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK BRANCH
        // ==================================================

        const [branch] = await connection.query(
            `
            SELECT id
            FROM cst_branch
            WHERE id = ?
    LIMIT 1
        `,
            [Number(branch_id)]
        );

        if (branch.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid branch"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK ROLE
        // ==================================================

        const [role] = await connection.query(
            `
            SELECT id
            FROM cst_roles
            WHERE id = ?
    LIMIT 1
        `,
            [Number(role_id)]
        );

        if (role.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid role"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK USER
        // ==================================================

        if (user_id) {

            const [user] = await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE id = ?
    LIMIT 1
        `,
                [Number(user_id)]
            );

            if (user.length === 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "Invalid user_id"
                    },
                    { status: 400 }
                );
            }


            // One user = one staff
            const [existingUser] = await connection.query(
                `
                SELECT id
                FROM cst_staff
                WHERE user_id = ?
    LIMIT 1
                `,
                [Number(user_id)]
            );

            if (existingUser.length > 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "This user is already assigned to staff"
                    },
                    { status: 409 }
                );
            }
        }


        // ==================================================
        // GENERATE APPOINTMENT NUMBER
        // ==================================================

        let appointmentNo;

        const year = new Date().getFullYear();

        while (true) {

            const random = Math.floor(
                100000 + Math.random() * 900000
            );

            appointmentNo = `APT-${year}-${random}`;

            const [existing] = await connection.query(
                `
                SELECT id
                FROM cst_staff
                WHERE appointment_no = ?
    LIMIT 1
        `,
                [appointmentNo]
            );

            if (existing.length === 0) {
                break;
            }
        }


        // ==================================================
        // INSERT
        // ==================================================

        const [result] = await connection.query(
            `
            INSERT INTO cst_staff(
            user_id,
            appointment_no,
            role_id,
            academy_id,
            branch_id,
            first_name,
            last_name,
            father_name,
            mother_name,
            gender,
            speciality,
            experience,
            previous_academy,
            previous_academy_duration,
            qualification,
            achievement,
            last_salary,
            current_salary,
            dob,
            date_of_joining,
            date_of_appointment,
            status
        )
VALUES(
                ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?
)
    `,
            [
                user_id || null,
                appointmentNo,
                Number(role_id),
                Number(academy_id),
                Number(branch_id),
                String(first_name).trim(),
                last_name || null,
                father_name || null,
                mother_name || null,
                gender || null,
                speciality || null,
                experience || null,
                previous_academy || null,
                previous_academy_duration || null,
                qualification || null,
                achievement || null,
                last_salary || 0,
                current_salary || 0,
                dob || null,
                date_of_joining || null,
                date_of_appointment || null,
                status ?? 1
            ]
        );

        await connection.query(
            `
INSERT INTO cst_user_branches
(
    branch_id,
    apointment_no
)
VALUES (?, ?)
`,
            [
                Number(branch_id),
                appointmentNo
            ]
        );

        return NextResponse.json(
            {
                success: true,
                message: "Staff created successfully",
                data: {
                    id: result.insertId,
                    appointment_no: appointmentNo
                }
            },
            { status: 201 }
        );

    } catch (error) {

        console.error("POST STAFF ERROR:", error);
        console.error("POST STAFF ERROR:", error);
        console.error("Code:", error.code);
        console.error("SQL Message:", error.sqlMessage);
        console.error("SQL:", error.sql);
        return NextResponse.json(
            {
                success: false,
                message: "Failed to create staff"
            },
            { status: 500 }
        );

    } finally {
        connection.release();
    }
}
