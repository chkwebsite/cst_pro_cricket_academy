import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

// ======================================================
// GET SINGLE STAFF
// ======================================================

export async function GET(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;

        const [rows] = await connection.query(
            `
SELECT
s.*,

    r.role_name,
    ac.academy_name,
    b.branch_name

            FROM cst_staff s

            LEFT JOIN cst_roles r
                ON r.id = s.role_id

            LEFT JOIN cst_branch b
                ON b.id = s.branch_id

            LEFT JOIN cst_academy ac
                ON s.academy_id = ac.id

            WHERE s.id = ?
    AND s.is_deleted = 0

            LIMIT 1
    `,
            [Number(id)]
        );

        if (rows.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Staff not found"
                },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            data: rows[0]
        });

    } catch (error) {

        console.error("GET SINGLE STAFF ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to fetch staff"
            },
            { status: 500 }
        );

    } finally {
        connection.release();
    }
}


// ======================================================
// PUT STAFF
// ======================================================

export async function PUT(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;

        const body = await request.json();

        const {
            user_id,
            role_id,
            academy_id,
            branch_id,
            first_name,
            last_name,
            father_name,
            mother_name,
            gender,
            speciality,
            experience,
            previous_academy,
            previous_academy_duration,
            qualification,
            achievement,
            last_salary,
            current_salary,
            dob,
            date_of_joining,
            date_of_appointment,
            status
        } = body;


        // ==================================================
        // CHECK STAFF
        // ==================================================

        const [staff] = await connection.query(
            `
            SELECT id, user_id
            FROM cst_staff
            WHERE id = ?
    AND is_deleted = 0
            LIMIT 1
    `,
            [Number(id)]
        );

        if (staff.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Staff not found"
                },
                { status: 404 }
            );
        }


        // ==================================================
        // VALIDATION
        // ==================================================

        if (!role_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Role is required"
                },
                { status: 400 }
            );
        }

        if (!branch_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Branch is required"
                },
                { status: 400 }
            );
        }

        if (!first_name || !String(first_name).trim()) {
            return NextResponse.json(
                {
                    success: false,
                    message: "First name is required"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK BRANCH
        // ==================================================

        const [branch] = await connection.query(
            `
            SELECT id
            FROM cst_branch
            WHERE id = ?
    LIMIT 1
        `,
            [Number(branch_id)]
        );

        if (branch.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid branch"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK ROLE
        // ==================================================

        const [role] = await connection.query(
            `
            SELECT id
            FROM cst_roles
            WHERE id = ?
    LIMIT 1
        `,
            [Number(role_id)]
        );

        if (role.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid role"
                },
                { status: 400 }
            );
        }


        // ==================================================
        // CHECK USER
        // ==================================================

        if (user_id) {

            const [user] = await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE id = ?
    LIMIT 1
        `,
                [Number(user_id)]
            );

            if (user.length === 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "Invalid user_id"
                    },
                    { status: 400 }
                );
            }


            const [existingUser] = await connection.query(
                `
                SELECT id
                FROM cst_staff
                WHERE user_id = ?
    AND id != ?
        LIMIT 1
            `,
                [
                    Number(user_id),
                    Number(id)
                ]
            );

            if (existingUser.length > 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "This user is already assigned to another staff"
                    },
                    { status: 409 }
                );
            }
        }


        // ==================================================
        // UPDATE
        // ==================================================

        await connection.query(
            `
            UPDATE cst_staff

SET
user_id = ?,
    role_id = ?,
    academy_id = ?,
    branch_id = ?,
    first_name = ?,
    last_name = ?,
    father_name = ?,
    mother_name = ?,
    gender = ?,
    speciality = ?,
    experience = ?,
    previous_academy = ?,
    previous_academy_duration = ?,
    qualification = ?,
    achievement = ?,
    last_salary = ?,
    current_salary = ?,
    dob = ?,
    date_of_joining = ?,
    date_of_appointment = ?,
    status = ?

        WHERE id = ?
            `,
            [
                user_id || null,
                Number(role_id),
                Number(academy_id),
                Number(branch_id),
                String(first_name).trim(),
                last_name || null,
                father_name || null,
                mother_name || null,
                gender || null,
                speciality || null,
                experience || null,
                previous_academy || null,
                previous_academy_duration || null,
                qualification || null,
                achievement || null,
                last_salary || 0,
                current_salary || 0,
                dob || null,
                date_of_joining || null,
                date_of_appointment || null,
                status ?? 1,
                Number(id)
            ]
        );

        const [GetBranchRows] = await connection.query(`SELECT * from cst_user_branches WHERE branch_id = ?
            LIMIT 1`, [branch_id]);

        if (GetBranchRows.length > 0) {
            const [UpdBranchRows] = await connection.query(
                `UPDATE cst_user_branches
         SET branch_id = ?
         WHERE id = ?`,
                [
                    Number(branch_id),
                    GetBranchRows[0].id,
                ]
            );
        }

        return NextResponse.json({
            success: true,
            message: "Staff updated successfully"
        });

    } catch (error) {

        console.error("PUT STAFF ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to update staff"
            },
            { status: 500 }
        );

    } finally {
        connection.release();
    }
}


// ======================================================
// DELETE STAFF - SOFT DELETE
// ======================================================

export async function DELETE(request, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;

        const [result] = await connection.query(
            `
            UPDATE cst_staff

SET
is_deleted = 1,
    status = 0

            WHERE id = ?
    AND is_deleted = 0
        `,
            [Number(id)]
        );

        if (result.affectedRows === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Staff not found"
                },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            message: "Staff deleted successfully"
        });

    } catch (error) {

        console.error("DELETE STAFF ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to delete staff"
            },
            { status: 500 }
        );

    } finally {
        connection.release();
    }
}
