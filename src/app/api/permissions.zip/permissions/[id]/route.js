import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

//GET SINGLE

export async function GET(req, { params }) {
    const connection = await pool.getConnection();

    try {
        const { id } = await params;
        const [rows] = await connection.query(` SELECT p.module_name, p.permission_name, p.status from cst_permissions p WHERE p.id = ?`, [id]);
        if (rows.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Permission not found"
            }, { status: 500 });
        }
        return NextResponse.json({
            success: true,
            data: rows[0]
        })
    } catch (error) {
        return NextResponse.json(
            {
                success: false,
                message:
                    "Failed to fetch Permission",
                error: error.message,
            },
            { status: 500 }
        );
    } finally {
        connection.release();
    }
}

// UPDATE PERMISSION

export async function PUT(request, { params }) {

    const connection = await pool.getConnection();
    try {
        const body = await request.json();
        const { id } = await params;
        const { module_name, permission_name, status } = body;
        //CHECK PERMISSION
        const [checkPermission] = await connection.query(`SELECT id FROM cst_permissions WHERE id = ?`, [id]);
        if (checkPermission.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Permission not found"
            }, { status: 404 });
        }
        //VALIDATION
        if (!module_name) {
            return NextResponse.json({
                success: false,
                message: "Module name is required"
            }, { status: 400 });
        }
        if (!permission_name) {
            return NextResponse.json({
                success: false,
                message: "Permission name in required"
            })
        }
        if (status !== 0 && status !== 1) {
            return NextResponse.json({
                success: false,
                message: "Status must be 0 or 1"
            })
        }

        //DUPLICATE
        const [existingModule_name] = await connection.query(`SELECT id FROM cst_permissions WHERE module_name = ? AND id != ? LIMIT 1`, [module_name, id]);
        if (existingModule_name.length > 0) {
            return NextResponse.json({
                success: false,
                message: "Module name already exists "
            }, { status: 409 });
        }
        const [existingPermission_name] = await connection.query(`SELECT id FROM cst_permissions WHERE permission_name = ? AND id != ? LIMIT 1`, [permission_name, id]);
        if (existingPermission_name.length > 0) {
            return NextResponse.json({
                success: false,
                message: "Permission name already exists "
            }, { status: 409 });
        }

        await connection.query(`UPDATE cst_permissions SET module_name =?, permission_name =?, status =? WHERE id = ?`,
            [module_name, permission_name, status, id]);
        return NextResponse.json({
            success: true,
            message: "Permission updated successfully"
        }, { status: 200 });
    } catch (error) {
        return NextResponse.json({
            success: false,
            error: error.message
        }, { status: 500 });
    } finally {
        connection.release();
    }
}