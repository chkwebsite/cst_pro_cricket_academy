import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

// =====================================================
// GET SINGLE USER PROGRAM
// GET /api/user-programs/[id]
// =====================================================

export async function GET(request, { params }) {
    let connection;

    try {
        const { id } = await params;

        if (!id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User program ID is required"
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        const [rows] = await connection.query(
            `
            SELECT
                up.id,
                up.user_id,
                up.program_id,
                up.branch_id,
                up.admission_players_id,
                up.start_date,
                up.end_date,
                up.status,
                up.created_at,
                up.updated_at
            FROM cst_user_programs up
            WHERE up.id = ?
              AND up.is_deleted = 0
            LIMIT 1
            `,
            [id]
        );

        if (rows.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User program not found"
                },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            data: rows[0]
        });

    } catch (error) {
        console.error("GET SINGLE USER PROGRAM ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to get user program",
                error: error.message
            },
            { status: 500 }
        );

    } finally {
        if (connection) {
            connection.release();
        }
    }
}

// =====================================================
// PUT USER PROGRAM
// PUT /api/user-programs/[id]
// =====================================================

export async function PUT(request, { params }) {
    let connection;

    try {
        const { id } = await params;

        if (!id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User program ID is required"
                },
                { status: 400 }
            );
        }

        const body = await request.json();

        const {
            user_id,
            program_id,
            branch_id,
            admission_players_id,
            start_date,
            end_date,
            status
        } = body;

        // =================================================
        // VALIDATION
        // =================================================

        if (!program_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "program_id is required"
                },
                { status: 400 }
            );
        }

        if (!branch_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "branch_id is required"
                },
                { status: 400 }
            );
        }

        if (!admission_players_id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "admission_players_id is required"
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        await connection.beginTransaction();

        // =================================================
        // CHECK EXISTING
        // =================================================

        const [existing] = await connection.query(
            `
            SELECT id
            FROM cst_user_programs
            WHERE id = ?
              AND is_deleted = 0
            LIMIT 1
            `,
            [id]
        );

        if (existing.length === 0) {
            await connection.rollback();

            return NextResponse.json(
                {
                    success: false,
                    message: "User program not found"
                },
                { status: 404 }
            );
        }

        // =================================================
        // UPDATE
        // =================================================

        await connection.query(
            `
            UPDATE cst_user_programs
            SET
                user_id = ?,
                program_id = ?,
                branch_id = ?,
                admission_players_id = ?,
                start_date = ?,
                end_date = ?,
                status = ?
            WHERE id = ?
              AND is_deleted = 0
            `,
            [
                user_id || null,
                program_id,
                branch_id,
                admission_players_id,
                start_date || null,
                end_date || null,
                status !== undefined ? Number(status) : 1,
                id
            ]
        );

        await connection.commit();

        return NextResponse.json({
            success: true,
            message: "User program updated successfully"
        });

    } catch (error) {
        if (connection) {
            await connection.rollback();
        }

        console.error("UPDATE USER PROGRAM ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to update user program",
                error: error.message
            },
            { status: 500 }
        );

    } finally {
        if (connection) {
            connection.release();
        }
    }
}

// =====================================================
// DELETE USER PROGRAM
// DELETE /api/user-programs/[id]
// =====================================================

export async function DELETE(request, { params }) {
    let connection;

    try {
        const { id } = await params;

        if (!id) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User program ID is required"
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        const [result] = await connection.query(
            `
            UPDATE cst_user_programs
            SET is_deleted = 1
            WHERE id = ?
              AND is_deleted = 0
            `,
            [id]
        );

        if (result.affectedRows === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "User program not found"
                },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            message: "User program deleted successfully"
        });

    } catch (error) {
        console.error("DELETE USER PROGRAM ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to delete user program",
                error: error.message
            },
            { status: 500 }
        );

    } finally {
        if (connection) {
            connection.release();
        }
    }
}