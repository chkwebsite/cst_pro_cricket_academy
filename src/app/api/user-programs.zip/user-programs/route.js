import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";

// =====================================================
// GET USER PROGRAMS
// GET /api/user-programs
// =====================================================
export async function GET(request) {
    let connection;

    try {
        const { searchParams } = new URL(request.url);

        const user_id = searchParams.get("user_id");
        const program_id = searchParams.get("program_id");
        const branch_id = searchParams.get("branch_id");
        const admission_players_id = searchParams.get("admission_players_id");
        const status = searchParams.get("status");
        const search = searchParams.get("search");

        const page = Math.max(
            Number(searchParams.get("page") || 1),
            1
        );

        const limit = Math.min(
            Math.max(Number(searchParams.get("limit") || 20), 1),
            100
        );

        const offset = (page - 1) * limit;

        connection = await pool.getConnection();

        let where = `
            WHERE up.is_deleted = 0
        `;

        const values = [];

        if (user_id) {
            where += ` AND up.user_id = ?`;
            values.push(user_id);
        }

        if (program_id) {
            where += ` AND up.program_id = ?`;
            values.push(program_id);
        }

        if (branch_id) {
            where += ` AND up.branch_id = ?`;
            values.push(branch_id);
        }

        if (admission_players_id) {
            where += ` AND up.admission_players_id = ?`;
            values.push(admission_players_id);
        }

        if (status !== null && status !== "") {
            where += ` AND up.status = ?`;
            values.push(Number(status));
        }

        if (search) {
            where += `
                AND (
                    CAST(up.id AS CHAR) LIKE ?
                    OR CAST(up.user_id AS CHAR) LIKE ?
                    OR CAST(up.program_id AS CHAR) LIKE ?
                    OR CAST(up.admission_players_id AS CHAR) LIKE ?
                )
            `;

            const keyword = `%${search}%`;

            values.push(
                keyword,
                keyword,
                keyword,
                keyword
            );
        }

        // =================================================
        // COUNT
        // =================================================

        const [countRows] = await connection.query(
            `
            SELECT COUNT(*) AS total
            FROM cst_user_programs up
            ${where}
            `,
            values
        );

        const total = Number(countRows[0].total);

        // =================================================
        // LIST
        // =================================================

        const [rows] = await connection.query(
            `
            SELECT
                up.id,
                up.user_id,
                up.program_id,
                up.branch_id,
                up.admission_players_id,
                up.start_date,
                up.end_date,
                up.status,
                up.created_at,
                up.updated_at
            FROM cst_user_programs up
            ${where}
            ORDER BY up.id DESC
            LIMIT ? OFFSET ?
            `,
            [
                ...values,
                limit,
                offset
            ]
        );

        return NextResponse.json({
            success: true,
            data: rows,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit)
            }
        });

    } catch (error) {
        console.error("GET USER PROGRAMS ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to get user programs",
                error: error.message
            },
            { status: 500 }
        );

    } finally {
        if (connection) {
            connection.release();
        }
    }
}