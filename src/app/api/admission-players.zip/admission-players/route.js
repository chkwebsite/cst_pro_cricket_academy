import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";
import fs from "fs/promises";
import path from "path";


// =====================================================
// UPLOAD DIRECTORY
// =====================================================
const uploadDir = path.join(
    process.cwd(),
    "public",
    "images",
    "uploads",
    "admission-players"
);


// =====================================================
// GET ALL PLAYERS
// =====================================================
export async function GET(request) {
    const connection = await pool.getConnection();

    try {
        const { searchParams } = new URL(request.url);

        const branch_id = searchParams.get("branch_id");
        const role_id = searchParams.get("role_id");
        const status = searchParams.get("status");
        const under_age = searchParams.get("under_age");
        const search = searchParams.get("search");

        let sql = `
SELECT
p.id,
    p.user_id,
    p.admission_no,

    p.first_name,
    p.last_name,
    p.father_name,
    p.mother_name,

    p.email,
    p.phone,

    p.address,
    p.city,
    p.state,
    p.pin_code,

    p.under_age,
    p.gender,

    p.aadhaar_no,
    p.aadhaar_card,

    p.playing_academy,

    p.branch_id,
    b.branch_name,

    p.role_id,
    r.role_name,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_admission_players p

            INNER JOIN cst_branch b
                ON b.id = p.branch_id

            INNER JOIN cst_roles r
                ON r.id = p.role_id

            WHERE p.is_deleted = 0
    `;

        const values = [];

        // BRANCH FILTER
        if (branch_id) {
            sql += ` AND p.branch_id = ? `;
            values.push(branch_id);
        }

        // ROLE FILTER
        if (role_id) {
            sql += ` AND p.role_id = ? `;
            values.push(role_id);
        }

        // STATUS FILTER
        if (status !== null && status !== "") {
            sql += ` AND p.status = ? `;
            values.push(status);
        }

        // UNDER AGE FILTER
        if (under_age !== null && under_age !== "") {
            sql += ` AND p.under_age = ? `;
            values.push(under_age);
        }

        // SEARCH
        if (search) {
            sql += `
                AND(
        p.admission_no LIKE ?
        OR p.first_name LIKE ?
        OR p.last_name LIKE ?
        OR p.father_name LIKE ?
        OR p.phone LIKE ?
        OR p.email LIKE ?
                )
    `;

            const searchValue = `% ${search}% `;

            values.push(
                searchValue,
                searchValue,
                searchValue,
                searchValue,
                searchValue,
                searchValue
            );
        }

        sql += ` ORDER BY p.id DESC`;

        const [rows] = await connection.query(sql, values);

        return NextResponse.json({
            success: true,
            count: rows.length,
            data: rows
        });

    } catch (error) {
        console.error("GET ADMISSION PLAYERS ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to fetch admission players"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}


// =====================================================
// CREATE PLAYER
// =====================================================
export async function POST(request) {
    const connection = await pool.getConnection();

    try {
        const formData = await request.formData();

        const user_id = formData.get("user_id");
        const admission_no = formData.get("admission_no");
        const first_name = formData.get("first_name");
        const last_name = formData.get("last_name");
        const father_name = formData.get("father_name");
        const mother_name = formData.get("mother_name");

        const email = formData.get("email");
        const phone = formData.get("phone");

        const address = formData.get("address");
        const city = formData.get("city");
        const state = formData.get("state");
        const pin_code = formData.get("pin_code");

        const under_age = formData.get("under_age");
        const gender = formData.get("gender");

        const aadhaar_no = formData.get("aadhaar_no");
        const playing_academy = formData.get("playing_academy");

        const branch_id = formData.get("branch_id");
        const role_id = formData.get("role_id");

        const status = formData.get("status");

        const aadhaarFile = formData.get("aadhaar_card");


        // =================================================
        // VALIDATION
        // =================================================

        if (!admission_no || !String(admission_no).trim()) {
            return NextResponse.json({
                success: false,
                message: "Admission number is required"
            }, { status: 400 });
        }

        if (!first_name || !String(first_name).trim()) {
            return NextResponse.json({
                success: false,
                message: "First name is required"
            }, { status: 400 });
        }

        if (!branch_id) {
            return NextResponse.json({
                success: false,
                message: "Branch ID is required"
            }, { status: 400 });
        }

        if (!role_id) {
            return NextResponse.json({
                success: false,
                message: "Role ID is required"
            }, { status: 400 });
        }


        // =================================================
        // CHECK ADMISSION NUMBER
        // =================================================

        const [existingAdmission] = await connection.query(
            `
            SELECT id
            FROM cst_admission_players
            WHERE admission_no = ?
    LIMIT 1
        `,
            [String(admission_no).trim()]
        );

        if (existingAdmission.length > 0) {
            return NextResponse.json({
                success: false,
                message: "Admission number already exists"
            }, { status: 409 });
        }


        // =================================================
        // CHECK BRANCH
        // =================================================

        const [branch] = await connection.query(
            `
            SELECT id
            FROM cst_branch
            WHERE id = ?
    AND status = 1
            LIMIT 1
    `,
            [branch_id]
        );

        if (branch.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Branch not found"
            }, { status: 404 });
        }


        // =================================================
        // CHECK ROLE
        // =================================================

        const [role] = await connection.query(
            `
            SELECT id
            FROM cst_roles
            WHERE id = ?
    AND status = 1
            LIMIT 1
    `,
            [role_id]
        );

        if (role.length === 0) {
            return NextResponse.json({
                success: false,
                message: "Role not found"
            }, { status: 404 });
        }


        // =================================================
        // CHECK USER
        // =================================================

        if (user_id) {

            const [user] = await connection.query(
                `
                SELECT id
                FROM cst_users
                WHERE id = ?
    LIMIT 1
                `,
                [user_id]
            );

            if (user.length === 0) {
                return NextResponse.json({
                    success: false,
                    message: "User not found"
                }, { status: 404 });
            }
        }


        // =================================================
        // UPLOAD AADHAAR CARD
        // =================================================

        let aadhaarCardPath = null;

        if (
            aadhaarFile &&
            typeof aadhaarFile === "object" &&
            aadhaarFile.name
        ) {

            const allowedTypes = [
                "image/jpeg",
                "image/png",
                "image/webp",
                "application/pdf"
            ];

            if (!allowedTypes.includes(aadhaarFile.type)) {
                return NextResponse.json({
                    success: false,
                    message: "Only JPG, PNG, WEBP and PDF files are allowed"
                }, { status: 400 });
            }


            // 5 MB
            if (aadhaarFile.size > 5 * 1024 * 1024) {
                return NextResponse.json({
                    success: false,
                    message: "Aadhaar card file must be less than 5MB"
                }, { status: 400 });
            }


            await fs.mkdir(uploadDir, {
                recursive: true
            });


            const extension = path.extname(aadhaarFile.name);

            const fileName =
                `aadhaar_${Date.now()}_${Math.floor(Math.random() * 100000)}${extension} `;

            const filePath = path.join(
                uploadDir,
                fileName
            );

            const buffer = Buffer.from(
                await aadhaarFile.arrayBuffer()
            );

            await fs.writeFile(
                filePath,
                buffer
            );

            aadhaarCardPath =
                `/ uploads / admission - players / ${fileName} `;
        }


        // =================================================
        // INSERT
        // =================================================

        const [result] = await connection.query(
            `
            INSERT INTO cst_admission_players
    (
        user_id,
        admission_no,

        first_name,
        last_name,
        father_name,
        mother_name,

        email,
        phone,

        address,
        city,
        state,
        pin_code,

        under_age,
        gender,

        aadhaar_no,
        aadhaar_card,

        playing_academy,

        branch_id,
        role_id,

        status
    )
VALUES
    (
                ?, ?,
                ?, ?, ?, ?,
                ?, ?,
                ?, ?, ?, ?,
                ?, ?,
                ?, ?,
                ?,
                ?, ?,
                ?
)
    `,
            [
                user_id || null,
                String(admission_no).trim(),

                String(first_name).trim(),
                last_name || null,
                father_name || null,
                mother_name || null,

                email || null,
                phone || null,

                address || null,
                city || null,
                state || null,
                pin_code || null,

                under_age ?? 0,
                gender || null,

                aadhaar_no || null,
                aadhaarCardPath,

                playing_academy || null,

                branch_id,
                role_id,

                status ?? 1
            ]
        );


        // =================================================
        // GET CREATED PLAYER
        // =================================================

        const [rows] = await connection.query(
            `
SELECT
p.id,
    p.user_id,
    p.admission_no,

    p.first_name,
    p.last_name,
    p.father_name,
    p.mother_name,

    p.email,
    p.phone,

    p.address,
    p.city,
    p.state,
    p.pin_code,

    p.under_age,
    p.gender,

    p.aadhaar_no,
    p.aadhaar_card,

    p.playing_academy,

    p.branch_id,
    b.branch_name,

    p.role_id,
    r.role_name,

    p.status,
    p.is_deleted,

    p.created_at,
    p.updated_at

            FROM cst_admission_players p

            INNER JOIN cst_branch b
                ON b.id = p.branch_id

            INNER JOIN cst_roles r
                ON r.id = p.role_id

            WHERE p.id = ?

    LIMIT 1
        `,
            [result.insertId]
        );


        return NextResponse.json({
            success: true,
            message: "Admission player created successfully",
            data: rows[0]
        }, { status: 201 });


    } catch (error) {
        console.error("CREATE ADMISSION PLAYER ERROR:", error);

        return NextResponse.json({
            success: false,
            message: "Failed to create admission player"
        }, { status: 500 });

    } finally {
        connection.release();
    }
}