import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";


const validPaymentModes = [
    "Cash",
    "UPI",
    "Card",
    "Bank Transfer",
    "Cheque",
];

// GET: Get single ground payment
export async function GET(request, { params }) {
    let connection;


    try {
        const { id } = await params;
        const paymentId = Number(id);

        if (!Number.isInteger(paymentId) || paymentId <= 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid payment ID",
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        const [rows] = await connection.execute(
            `SELECT *
        FROM cst_ground_payments
         WHERE id = ?
        LIMIT 1`,
            [paymentId]
        );

        if (rows.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground payment not found",
                },
                { status: 404 }
            );
        }

        return NextResponse.json({
            success: true,
            message: "Ground payment fetched successfully",
            data: rows[0],
        });

    } catch (error) {
        console.error("GET Ground Payment Error:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to fetch ground payment",
                error: error.message,
            },
            { status: 500 }
        );

    } finally {
        if (connection) connection.release();
    }


}

// PUT: Update ground payment
export async function PUT(request, { params }) {
    let connection;


    try {
        const { id } = await params;
        const paymentId = Number(id);

        if (!Number.isInteger(paymentId) || paymentId <= 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid payment ID",
                },
                { status: 400 }
            );
        }

        const body = await request.json();

        const {
            booking_id,
            payment_date,
            amount,
            payment_mode,
            transaction_no,
            remarks,
        } = body;

        if (
            booking_id === undefined ||
            booking_id === null ||
            booking_id === "" ||
            !payment_date ||
            amount === undefined ||
            amount === null ||
            amount === "" ||
            !payment_mode
        ) {
            return NextResponse.json(
                {
                    success: false,
                    message: "booking_id, payment_date, amount and payment_mode are required",
                },
                { status: 400 }
            );
        }

        const bookingId = Number(booking_id);
        const paymentAmount = Number(amount);

        if (!Number.isInteger(bookingId) || bookingId <= 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid booking_id",
                },
                { status: 400 }
            );
        }

        if (!Number.isFinite(paymentAmount) || paymentAmount <= 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Payment amount must be greater than zero",
                },
                { status: 400 }
            );
        }

        if (!/^\d{4}-\d{2}-\d{2}$/.test(payment_date)) {
            return NextResponse.json(
                {
                    success: false,
                    message: "payment_date must be in YYYY-MM-DD format",
                },
                { status: 400 }
            );
        }

        if (!validPaymentModes.includes(payment_mode)) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid payment_mode",
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        // Check existing payment
        const [existingPayments] = await connection.execute(
            `SELECT id
         FROM cst_ground_payments
         WHERE id = ?
        LIMIT 1`,
            [paymentId]
        );

        if (existingPayments.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground payment not found",
                },
                { status: 404 }
            );
        }

        // Check booking exists
        const [bookings] = await connection.execute(
            `SELECT id
         FROM cst_ground_bookings
         WHERE id = ?
        LIMIT 1`,
            [bookingId]
        );

        if (bookings.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground booking not found",
                },
                { status: 404 }
            );
        }

        await connection.execute(
            `UPDATE cst_ground_payments
    SET
    booking_id = ?,
        payment_date = ?,
        amount = ?,
        payment_mode = ?,
        transaction_no = ?,
        remarks = ?
            WHERE id = ? `,
            [
                bookingId,
                payment_date,
                paymentAmount,
                payment_mode,
                transaction_no || null,
                remarks || null,
                paymentId,
            ]
        );

        const [updatedPayments] = await connection.execute(
            `SELECT *
        FROM cst_ground_payments
         WHERE id = ? `,
            [paymentId]
        );

        return NextResponse.json({
            success: true,
            message: "Ground payment updated successfully",
            data: updatedPayments[0],
        });

    } catch (error) {
        console.error("PUT Ground Payment Error:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to update ground payment",
                error: error.message,
            },
            { status: 500 }
        );

    } finally {
        if (connection) connection.release();
    }


}

// DELETE: Delete ground payment
export async function DELETE(request, { params }) {
    let connection;


    try {
        const { id } = await params;
        const paymentId = Number(id);

        if (!Number.isInteger(paymentId) || paymentId <= 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Invalid payment ID",
                },
                { status: 400 }
            );
        }

        connection = await pool.getConnection();

        const [existingPayments] = await connection.execute(
            `SELECT id
         FROM cst_ground_payments
         WHERE id = ?
        LIMIT 1`,
            [paymentId]
        );

        if (existingPayments.length === 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground payment not found",
                },
                { status: 404 }
            );
        }

        await connection.execute(
            `DELETE FROM cst_ground_payments
         WHERE id = ? `,
            [paymentId]
        );

        return NextResponse.json({
            success: true,
            message: "Ground payment deleted successfully",
        });

    } catch (error) {
        console.error("DELETE Ground Payment Error:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to delete ground payment",
                error: error.message,
            },
            { status: 500 }
        );

    } finally {
        if (connection) connection.release();
    }


}
