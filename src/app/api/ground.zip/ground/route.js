import { NextResponse } from "next/server";
import pool from "@/app/components/lib/db";


// ======================================================
// GET ALL GROUNDS / FILTER
// GET /api/grounds
// GET /api/grounds?name=Gurgaon
// GET /api/grounds?code=GRD001
// GET /api/grounds?phone=9876
// GET /api/grounds?address=Sohna
// GET /api/grounds?name=Cricket&code=GRD&phone=9876&address=Gurgaon
// GET /api/grounds?status=1
// ======================================================
export async function GET(request) {
    let connection;

    try {
        connection = await pool.getConnection();

        const { searchParams } = new URL(request.url);

        const name = searchParams.get("name")?.trim() || "";
        const code = searchParams.get("code")?.trim() || "";
        const phone = searchParams.get("phone")?.trim() || "";
        const address = searchParams.get("address")?.trim() || "";
        const status = searchParams.get("status");

        let sql = `
            SELECT
                id,
                ground_name,
                ground_code,
                contact_person,
                phone,
                email,
                address,
                description,
                ground_facility,
                status,
                is_deleted,
                created_at,
                updated_at
            FROM cst_ground
            WHERE is_deleted = 0
        `;

        const values = [];

        // Ground Name
        if (name) {
            sql += ` AND ground_name LIKE ?`;
            values.push(`%${name}%`);
        }

        // Ground Code
        if (code) {
            sql += ` AND ground_code LIKE ?`;
            values.push(`%${code}%`);
        }

        // Phone
        if (phone) {
            sql += ` AND phone LIKE ?`;
            values.push(`%${phone}%`);
        }

        // Address
        if (address) {
            sql += ` AND address LIKE ?`;
            values.push(`%${address}%`);
        }

        // Status
        if (status !== null && status !== "") {
            sql += ` AND status = ?`;
            values.push(status);
        }

        sql += ` ORDER BY id DESC`;

        const [rows] = await connection.execute(sql, values);

        return NextResponse.json({
            success: true,
            message: "Grounds fetched successfully",
            data: rows,
            total: rows.length
        });

    } catch (error) {

        console.error("GET GROUNDS ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to fetch grounds",
                error: error.message
            },
            { status: 500 }
        );

    } finally {

        if (connection) {
            connection.release();
        }
    }
}


// ======================================================
// POST - ADD GROUND
// ======================================================
export async function POST(request) {
    let connection;

    try {
        connection = await pool.getConnection();

        const body = await request.json();

        const {
            ground_name,
            ground_code,
            contact_person,
            phone,
            email,
            address,
            description,
            ground_facility,
            status
        } = body;

        // ==========================================
        // VALIDATION
        // ==========================================

        if (!ground_name || !ground_name.trim()) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground name is required"
                },
                { status: 400 }
            );
        }

        if (!ground_code || !ground_code.trim()) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground code is required"
                },
                { status: 400 }
            );
        }

        if (!address || !address.trim()) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Address is required"
                },
                { status: 400 }
            );
        }

        // ==========================================
        // CHECK DUPLICATE GROUND CODE
        // ==========================================

        const [existingCode] = await connection.execute(
            `
            SELECT id
            FROM cst_ground
            WHERE ground_code = ?
            AND is_deleted = 0
            LIMIT 1
            `,
            [ground_code.trim()]
        );

        if (existingCode.length > 0) {
            return NextResponse.json(
                {
                    success: false,
                    message: "Ground code already exists"
                },
                { status: 409 }
            );
        }

        // ==========================================
        // CHECK DUPLICATE EMAIL
        // ==========================================

        if (email && email.trim()) {

            const [existingEmail] = await connection.execute(
                `
                SELECT id
                FROM cst_ground
                WHERE email = ?
                AND is_deleted = 0
                LIMIT 1
                `,
                [email.trim()]
            );

            if (existingEmail.length > 0) {
                return NextResponse.json(
                    {
                        success: false,
                        message: "Email already exists"
                    },
                    { status: 409 }
                );
            }
        }

        // ==========================================
        // INSERT GROUND
        // ==========================================

        const [result] = await connection.execute(
            `
            INSERT INTO cst_ground (
                ground_name,
                ground_code,
                contact_person,
                phone,
                email,
                address,
                description,
                ground_facility,
                status
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            `,
            [
                ground_name.trim(),
                ground_code.trim(),
                contact_person?.trim() || null,
                phone?.trim() || null,
                email?.trim() || null,
                address.trim(),
                description?.trim() || null,
                ground_facility?.trim() || null,
                status !== undefined ? status : 1
            ]
        );

        // ==========================================
        // GET INSERTED RECORD
        // ==========================================

        const [rows] = await connection.execute(
            `
            SELECT
                id,
                ground_name,
                ground_code,
                contact_person,
                phone,
                email,
                address,
                description,
                ground_facility,
                status,
                is_deleted,
                created_at,
                updated_at
            FROM cst_ground
            WHERE id = ?
            `,
            [result.insertId]
        );

        return NextResponse.json(
            {
                success: true,
                message: "Ground added successfully",
                data: rows[0]
            },
            { status: 201 }
        );

    } catch (error) {

        console.error("POST GROUND ERROR:", error);

        return NextResponse.json(
            {
                success: false,
                message: "Failed to add ground",
                error: error.message
            },
            { status: 500 }
        );

    } finally {

        if (connection) {
            connection.release();
        }
    }
}