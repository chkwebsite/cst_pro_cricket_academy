"use client";

import { ArrowLeft } from "lucide-react";
import Link from "next/link";
import TeamPlayerForm from "../TeamPlayerForm";

export default function TeamPlayerNew() {
    return (
        <div className="container-fluid">
            <div className="row g-4">
                <div className="col-12">
                    <div className="bg-white rounded-4 shadow-sm p-4 mb-4">
                        <Link href="/next_panel/team-players" className="btn btn-sm btn-outline-secondary mb-3">
                            <ArrowLeft size={16} className="me-2" /> Back to Team Players
                        </Link>
                        <h1 className="h4 mb-0">Add Player to Team</h1>
                        <p className="text-muted mb-0">Add an academy player or an outside player to a team.</p>
                    </div>
                </div>

                <div className="col-12">
                    <div className="bg-white rounded-4 shadow-sm p-4">
                        <TeamPlayerForm />
                    </div>
                </div>
            </div>
        </div>
    );
}
