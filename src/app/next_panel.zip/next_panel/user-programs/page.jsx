"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import {
    ArrowUpRight,
    Edit,
    Plus,
    Search,
    Trash2,
} from "lucide-react";

async function readJson(res) {
    const text = await res.text();

    if (!text) {
        return {};
    }

    try {
        return JSON.parse(text);
    } catch {
        return {
            message: text,
        };
    }
}

export default function UserProgramsPage() {
    const [rows, setRows] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const [search, setSearch] = useState("");
    const [status, setStatus] = useState("");
    const [programId, setProgramId] = useState("");
    const [programs, setPrograms] = useState([]);

    const [page, setPage] = useState(1);

    const [pagination, setPagination] = useState({
        total: 0,
        totalPages: 1,
    });

    // =====================================================
    // LOAD PROGRAMS LIST FOR FILTER
    // =====================================================

    useEffect(() => {
        let isMounted = true;
        async function loadPrograms() {
            try {
                const res = await fetch("/api/programs");
                const json = await readJson(res);
                if (isMounted && res.ok && json.success) {
                    setPrograms(json.data || []);
                }
            } catch {
                // Non-fatal — filter simply won't have options populated
            }
        }
        loadPrograms();
        return () => {
            isMounted = false;
        };
    }, []);

    // =====================================================
    // LOAD USER PROGRAMS
    // =====================================================

    const load = async (nextPage = page, overrides = {}) => {
        setLoading(true);
        setError(null);

        try {
            const p = new URLSearchParams({
                page: String(nextPage),
                limit: "20",
            });

            const currentSearch = overrides.search !== undefined ? overrides.search : search;
            const currentStatus = overrides.status !== undefined ? overrides.status : status;
            const currentProgramId = overrides.programId !== undefined ? overrides.programId : programId;

            if (currentSearch.trim()) {
                p.set("search", currentSearch.trim());
            }

            if (currentProgramId) {
                p.set("program_id", currentProgramId);
            }

            if (currentStatus) {
                p.set("status", currentStatus);
            }

            const res = await fetch(
                `/api/user-programs?${p.toString()}`
            );

            const json = await readJson(res);

            if (!res.ok) {
                throw new Error(
                    json.message ||
                    "Unable to load user programs."
                );
            }

            setRows(json.data || []);

            setPagination(
                json.pagination || {
                    total: 0,
                    totalPages: 1,
                }
            );

            setPage(nextPage);
        } catch (e) {
            setError(e.message);
        } finally {
            setLoading(false);
        }
    };

    // =====================================================
    // LOAD WHEN STATUS OR PROGRAM CHANGES
    // =====================================================

    useEffect(() => {
        // eslint-disable-next-line react-hooks/set-state-in-effect
        load(1);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [status, programId]);

    // =====================================================
    // SEARCH
    // =====================================================

    const submit = (e) => {
        e.preventDefault();
        load(1);
    };

    // =====================================================
    // CLEAR FILTERS
    // =====================================================

    const clear = () => {
        setSearch("");
        setProgramId("");
        setStatus("");
        load(1, { search: "", programId: "", status: "" });
    };

    // =====================================================
    // DELETE
    // =====================================================

    const remove = async (id) => {
        if (!confirm("Delete this user program?")) {
            return;
        }

        try {
            const res = await fetch(
                `/api/user-programs/${id}`,
                {
                    method: "DELETE",
                }
            );

            const json = await readJson(res);

            if (!res.ok) {
                throw new Error(
                    json.message ||
                    "Unable to delete."
                );
            }

            load(page);
        } catch (e) {
            setError(e.message);
        }
    };

    // =====================================================
    // UI
    // =====================================================

    return (
        <div className="container-fluid">
            <div className="row g-4">

                {/* =================================================
                    HEADER
                ================================================= */}

                <div className="col-12">
                    <div className="bg-white rounded-4 shadow-sm p-4 mb-4 d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-3">

                        <div>
                            <h1 className="h4 mb-2">
                                User Programs
                            </h1>

                            <p className="text-muted mb-0">
                                Manage program assignments for
                                admission players.
                            </p>
                        </div>

                        <Link
                            href="/next_panel/user-programs/new"
                            className="btn btn-primary fw-semibold"
                        >
                            <Plus
                                size={16}
                                className="me-2"
                            />

                            New User Program
                        </Link>
                    </div>
                </div>

                {/* =================================================
                    LIST
                ================================================= */}

                <div className="col-12">
                    <div className="bg-white rounded-4 shadow-sm p-3">

                        {/* =================================================
                            FILTERS
                        ================================================= */}

                        <div className="d-flex flex-column flex-md-row gap-2 mb-3">

                            <form
                                className="flex-grow-1"
                                onSubmit={submit}
                            >
                                <div
                                    className="input-group"
                                    style={{
                                        maxWidth: 560,
                                    }}
                                >
                                    <span className="input-group-text bg-white">
                                        <Search size={16} />
                                    </span>

                                    <input
                                        className="form-control"
                                        placeholder="Search ID, user, program, player..."
                                        value={search}
                                        onChange={(e) =>
                                            setSearch(
                                                e.target.value
                                            )
                                        }
                                    />

                                    <button
                                        type="submit"
                                        className="btn btn-outline-secondary"
                                    >
                                        Search
                                    </button>

                                    <button
                                        type="button"
                                        className="btn btn-outline-danger"
                                        onClick={clear}
                                    >
                                        Clear
                                    </button>
                                </div>
                            </form>

                            <select
                                className="form-select"
                                style={{
                                    maxWidth: 220,
                                }}
                                value={programId}
                                onChange={(e) =>
                                    setProgramId(
                                        e.target.value
                                    )
                                }
                            >
                                <option value="">
                                    All Programs
                                </option>
                                {programs.map((p) => (
                                    <option key={p.id} value={p.id}>
                                        {p.program_name}
                                    </option>
                                ))}
                            </select>

                            <select
                                className="form-select"
                                style={{
                                    maxWidth: 160,
                                }}
                                value={status}
                                onChange={(e) =>
                                    setStatus(
                                        e.target.value
                                    )
                                }
                            >
                                <option value="">
                                    All Statuses
                                </option>

                                <option value="1">
                                    Active
                                </option>

                                <option value="0">
                                    Inactive
                                </option>
                            </select>
                        </div>

                        {/* =================================================
                            ERROR
                        ================================================= */}

                        {error && (
                            <div className="alert alert-danger">
                                {error}
                            </div>
                        )}

                        {/* =================================================
                            LOADING
                        ================================================= */}

                        {loading ? (
                            <div className="text-center py-5 text-muted">
                                Loading user programs...
                            </div>
                        ) : rows.length === 0 ? (
                            <div className="text-center py-5 text-muted">
                                No user programs found.
                            </div>
                        ) : (
                            <div className="table-responsive">

                                <table className="table align-middle mb-0">

                                    <thead className="table-light">
                                        <tr>
                                            <th>ID</th>
                                            <th>User</th>
                                            <th>Program</th>
                                            <th>Branch</th>
                                            <th>
                                                Admission Player
                                            </th>
                                            <th>Dates</th>
                                            <th>Status</th>
                                            <th className="text-end">
                                                Actions
                                            </th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {rows.map((r) => (
                                            <tr key={r.id}>

                                                <td>
                                                    {r.id}
                                                </td>

                                                <td>
                                                    {r.first_name ?? "—"} {r.last_name ?? "—"}
                                                </td>

                                                <td>
                                                    {r.program_name}
                                                </td>

                                                <td>
                                                    {r.branch_name}
                                                </td>

                                                <td>
                                                    {
                                                        r.admission_players_id
                                                    }
                                                </td>

                                                <td>
                                                    <div>
                                                        {r.start_date
                                                            ? new Date(
                                                                r.start_date
                                                            ).toLocaleDateString()
                                                            : "—"}
                                                    </div>

                                                    <small className="text-muted">
                                                        to{" "}
                                                        {r.end_date
                                                            ? new Date(
                                                                r.end_date
                                                            ).toLocaleDateString()
                                                            : "—"}
                                                    </small>
                                                </td>

                                                <td>
                                                    <span
                                                        className={`badge ${r.status === 1
                                                            ? "bg-success"
                                                            : "bg-secondary"
                                                            }`}
                                                    >
                                                        {r.status === 1
                                                            ? "Active"
                                                            : "Inactive"}
                                                    </span>
                                                </td>

                                                <td className="text-end">
                                                    <div className="btn-group btn-group-sm">

                                                        <Link
                                                            href={`/next_panel/user-programs/${r.id}`}
                                                            className="btn btn-outline-primary"
                                                        >
                                                            <ArrowUpRight
                                                                size={16}
                                                            />
                                                        </Link>

                                                        <Link
                                                            href={`/next_panel/user-programs/${r.id}/edit`}
                                                            className="btn btn-outline-secondary"
                                                        >
                                                            <Edit
                                                                size={16}
                                                            />
                                                        </Link>

                                                        <button
                                                            type="button"
                                                            className="btn btn-outline-danger"
                                                            onClick={() =>
                                                                remove(
                                                                    r.id
                                                                )
                                                            }
                                                        >
                                                            <Trash2
                                                                size={16}
                                                            />
                                                        </button>

                                                    </div>
                                                </td>

                                            </tr>
                                        ))}
                                    </tbody>

                                </table>

                            </div>
                        )}

                        {/* =================================================
                            PAGINATION
                        ================================================= */}

                        {!loading &&
                            pagination.totalPages > 1 && (
                                <div className="d-flex justify-content-between align-items-center mt-3">

                                    <small className="text-muted">
                                        Total: {pagination.total}
                                    </small>

                                    <div className="btn-group">

                                        <button
                                            type="button"
                                            className="btn btn-outline-secondary btn-sm"
                                            disabled={page <= 1}
                                            onClick={() =>
                                                load(page - 1)
                                            }
                                        >
                                            Previous
                                        </button>

                                        <span className="btn btn-outline-secondary btn-sm disabled">
                                            {page} /{" "}
                                            {pagination.totalPages}
                                        </span>

                                        <button
                                            type="button"
                                            className="btn btn-outline-secondary btn-sm"
                                            disabled={
                                                page >=
                                                pagination.totalPages
                                            }
                                            onClick={() =>
                                                load(page + 1)
                                            }
                                        >
                                            Next
                                        </button>

                                    </div>
                                </div>
                            )}

                    </div>
                </div>

            </div>
        </div>
    );
}